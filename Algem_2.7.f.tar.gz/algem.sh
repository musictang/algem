#!/bin/sh
# version 2.7.f
CP=`dirname "$0"`
CLASSPATH=.:$CP/lib/*:$CP/Algem.jar:$CP/resources
java -cp $CLASSPATH net.algem.Algem algem.conf admin
#java -cp $CLASSPATH net.algem.Algem algem.conf $USER
