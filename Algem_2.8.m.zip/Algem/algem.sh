#!/bin/bash
# version 2.8.m

CP=$(cd -P $(dirname $0); pwd)

CLASSPATH=.:$CP:$CP/lib/*:$CP/Algem.jar:$CP/resources
java -cp $CLASSPATH net.algem.Algem $CP/algem.conf admin
#java -cp $CLASSPATH net.algem.Algem algem.conf $USER
