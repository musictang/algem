--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: array_agg(anyelement); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE array_agg(anyelement) (
    SFUNC = array_append,
    STYPE = anyarray,
    INITCOND = '{}'
);


ALTER AGGREGATE public.array_agg(anyelement) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: action; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE action (
    id integer NOT NULL,
    cours integer DEFAULT 0,
    niveau smallint DEFAULT 0,
    places smallint DEFAULT 0,
    tage smallint DEFAULT 0,
    statut smallint DEFAULT 0
);


ALTER TABLE public.action OWNER TO nobody;

--
-- Name: action_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE action_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.action_id_seq OWNER TO nobody;

--
-- Name: action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE action_id_seq OWNED BY action.id;


--
-- Name: action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('action_id_seq', 14, true);


SET default_with_oids = true;

--
-- Name: adresse; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE adresse (
    idper integer,
    adr1 character varying(50),
    adr2 character varying(50),
    cdp character(5),
    ville character varying(50),
    archive boolean DEFAULT false
);


ALTER TABLE public.adresse OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: analytique; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE analytique (
    code character varying(32) NOT NULL,
    libelle character varying(128) NOT NULL,
    actif boolean DEFAULT true
);


ALTER TABLE public.analytique OWNER TO nobody;

--
-- Name: article; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE article (
    id integer NOT NULL,
    designation character varying(128) NOT NULL,
    prix_u numeric DEFAULT 0.0,
    id_tva integer DEFAULT 1,
    compte integer,
    standard boolean DEFAULT false
);


ALTER TABLE public.article OWNER TO nobody;

--
-- Name: article_devis; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE article_devis (
    id_devis character varying(10) NOT NULL,
    id_article integer DEFAULT 0 NOT NULL,
    quantite numeric(6,2) DEFAULT 1.0
);


ALTER TABLE public.article_devis OWNER TO nobody;

--
-- Name: article_facture; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE article_facture (
    id_facture character varying(10) NOT NULL,
    id_echeancier integer NOT NULL,
    id_article integer DEFAULT 0 NOT NULL,
    quantite numeric(6,2) DEFAULT 1.0
);


ALTER TABLE public.article_facture OWNER TO nobody;

--
-- Name: article_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE article_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.article_id_seq OWNER TO nobody;

--
-- Name: article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE article_id_seq OWNED BY article.id;


--
-- Name: article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('article_id_seq', 6, true);


SET default_with_oids = true;

--
-- Name: atelier_ins; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE atelier_ins (
    id integer,
    adherent integer,
    instrument character varying(25)
);


ALTER TABLE public.atelier_ins OWNER TO nobody;

--
-- Name: banque; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE banque (
    code character(5) NOT NULL,
    nom character varying(30),
    multiguichet boolean
);


ALTER TABLE public.banque OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: carteabopersonne; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE carteabopersonne (
    id integer NOT NULL,
    idper integer,
    idcarte integer,
    date_achat date,
    restant integer
);


ALTER TABLE public.carteabopersonne OWNER TO nobody;

--
-- Name: carteabopersonne_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE carteabopersonne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.carteabopersonne_id_seq OWNER TO nobody;

--
-- Name: carteabopersonne_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE carteabopersonne_id_seq OWNED BY carteabopersonne.id;


--
-- Name: carteabopersonne_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('carteabopersonne_id_seq', 1, false);


--
-- Name: carteaborepet; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE carteaborepet (
    id integer NOT NULL,
    libelle character varying(128) NOT NULL,
    montant numeric DEFAULT 0.0,
    nbseances integer DEFAULT 10,
    dureemin integer DEFAULT 60
);


ALTER TABLE public.carteaborepet OWNER TO nobody;

--
-- Name: carteaborepet_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE carteaborepet_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.carteaborepet_id_seq OWNER TO nobody;

--
-- Name: carteaborepet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE carteaborepet_id_seq OWNED BY carteaborepet.id;


--
-- Name: carteaborepet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('carteaborepet_id_seq', 2, true);


SET default_with_oids = true;

--
-- Name: categorie_prof; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE categorie_prof (
    id integer,
    nom character varying(32)
);


ALTER TABLE public.categorie_prof OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: categorie_siteweb; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE categorie_siteweb (
    id integer NOT NULL,
    libelle character varying(32)
);


ALTER TABLE public.categorie_siteweb OWNER TO nobody;

--
-- Name: categorie_siteweb_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE categorie_siteweb_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.categorie_siteweb_id_seq OWNER TO nobody;

--
-- Name: categorie_siteweb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE categorie_siteweb_id_seq OWNED BY categorie_siteweb.id;


--
-- Name: categorie_siteweb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('categorie_siteweb_id_seq', 5, true);


--
-- Name: categorie_vacance; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE categorie_vacance (
    id integer NOT NULL,
    libelle character varying(32)
);


ALTER TABLE public.categorie_vacance OWNER TO nobody;

--
-- Name: categorie_vacance_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE categorie_vacance_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.categorie_vacance_id_seq OWNER TO nobody;

--
-- Name: categorie_vacance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE categorie_vacance_id_seq OWNED BY categorie_vacance.id;


--
-- Name: categorie_vacance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('categorie_vacance_id_seq', 3, true);


SET default_with_oids = true;

--
-- Name: cdpret; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE cdpret (
    cd integer,
    jour date,
    adh integer
);


ALTER TABLE public.cdpret OWNER TO nobody;

--
-- Name: cdrom; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE cdrom (
    id integer,
    artiste character(30),
    album character(35),
    label character(15),
    ref character(15),
    genre character(15)
);


ALTER TABLE public.cdrom OWNER TO nobody;

--
-- Name: cdtitre; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE cdtitre (
    cd integer,
    numero integer,
    titre character(35),
    interprete character(30)
);


ALTER TABLE public.cdtitre OWNER TO nobody;

--
-- Name: commande; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE commande (
    id integer,
    adh integer,
    payeur integer,
    creation date,
    facture character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public.commande OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: commande_cours; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE commande_cours (
    id integer NOT NULL,
    idcmd integer,
    module integer,
    idaction integer,
    debut time without time zone,
    fin time without time zone,
    datedebut date,
    datefin date,
    code integer DEFAULT 0
);


ALTER TABLE public.commande_cours OWNER TO nobody;

--
-- Name: commande_cours_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE commande_cours_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.commande_cours_id_seq OWNER TO nobody;

--
-- Name: commande_cours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE commande_cours_id_seq OWNED BY commande_cours.id;


--
-- Name: commande_cours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('commande_cours_id_seq', 7, true);


--
-- Name: commande_module; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE commande_module (
    id integer NOT NULL,
    idcmd integer,
    module integer,
    prix integer,
    debut date,
    fin date,
    reglement character(4),
    necheance smallint,
    paiement character(4)
);


ALTER TABLE public.commande_module OWNER TO nobody;

--
-- Name: commande_module_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE commande_module_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.commande_module_id_seq OWNER TO nobody;

--
-- Name: commande_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE commande_module_id_seq OWNED BY commande_module.id;


--
-- Name: commande_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('commande_module_id_seq', 3, true);


--
-- Name: compte; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE compte (
    id integer NOT NULL,
    numero character varying(32),
    libelle character varying(128),
    actif boolean DEFAULT true
);


ALTER TABLE public.compte OWNER TO nobody;

--
-- Name: compte_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE compte_id_seq
    START WITH 14
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.compte_id_seq OWNER TO nobody;

--
-- Name: compte_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE compte_id_seq OWNED BY compte.id;


--
-- Name: compte_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('compte_id_seq', 14, false);


--
-- Name: comptepref; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE comptepref (
    id character varying(128) NOT NULL,
    idcompte integer,
    idanalytique character varying(32)
);


ALTER TABLE public.comptepref OWNER TO nobody;

--
-- Name: config; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE config (
    clef character varying(32) NOT NULL,
    valeur character varying(128) NOT NULL
);


ALTER TABLE public.config OWNER TO nobody;

--
-- Name: idcours; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idcours
    INCREMENT BY 1
    MAXVALUE 2147483647
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.idcours OWNER TO nobody;

--
-- Name: idcours; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idcours', 19, true);


SET default_with_oids = true;

--
-- Name: cours; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE cours (
    id integer DEFAULT nextval('idcours'::regclass) NOT NULL,
    titre character varying(32),
    libelle character(16),
    nplaces smallint,
    niveau smallint,
    collectif boolean,
    code integer,
    ecole integer,
    actif boolean
);


ALTER TABLE public.cours OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: devis; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE devis (
    numero character varying(10) NOT NULL,
    date_emission date DEFAULT ('now'::text)::date NOT NULL,
    etablissement integer NOT NULL,
    emetteur integer NOT NULL,
    debiteur integer NOT NULL,
    prestation character varying(256),
    reference character varying(128),
    adherent integer DEFAULT 0,
    editable boolean DEFAULT true
);


ALTER TABLE public.devis OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: droits; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE droits (
    idper integer,
    nomtable character varying(32),
    lecture boolean,
    insertion boolean,
    modification boolean,
    suppression boolean
);


ALTER TABLE public.droits OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: echeancier2; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE echeancier2 (
    oid integer NOT NULL,
    echeance date,
    payeur integer,
    adherent integer,
    commande integer,
    reglement character(4),
    libelle character varying(50),
    montant integer,
    piece character varying(10),
    ecole integer,
    compte integer,
    paye boolean,
    transfert boolean,
    monnaie character(4),
    analytique character varying(13),
    facture character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public.echeancier2 OWNER TO nobody;

--
-- Name: echeancier2_oid_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE echeancier2_oid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.echeancier2_oid_seq OWNER TO nobody;

--
-- Name: echeancier2_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE echeancier2_oid_seq OWNED BY echeancier2.oid;


--
-- Name: echeancier2_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('echeancier2_oid_seq', 556, true);


--
-- Name: ecole; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE ecole (
    id integer NOT NULL,
    nom character varying(128) NOT NULL
);


ALTER TABLE public.ecole OWNER TO nobody;

--
-- Name: ecole_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE ecole_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.ecole_id_seq OWNER TO nobody;

--
-- Name: ecole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE ecole_id_seq OWNED BY ecole.id;


--
-- Name: ecole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('ecole_id_seq', 1, true);


SET default_with_oids = true;

--
-- Name: eleve; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE eleve (
    idper integer,
    profession character varying(48),
    datenais date,
    payeur integer,
    nadhesions integer,
    pratique integer,
    niveau integer,
    archiv boolean
);


ALTER TABLE public.eleve OWNER TO nobody;

--
-- Name: email; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE email (
    idper integer,
    email character varying(64),
    archive boolean,
    idx integer
);


ALTER TABLE public.email OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: facture; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE facture (
    numero character varying(10) NOT NULL,
    date_emission date DEFAULT ('now'::text)::date NOT NULL,
    etablissement integer NOT NULL,
    emetteur integer NOT NULL,
    debiteur integer NOT NULL,
    prestation character varying(256),
    reference character varying(128),
    adherent integer DEFAULT 0,
    acompte numeric DEFAULT 0.0
);


ALTER TABLE public.facture OWNER TO nobody;

--
-- Name: groupe; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE groupe (
    id integer NOT NULL,
    nom character varying(32) NOT NULL,
    style integer DEFAULT 0,
    referent integer DEFAULT 0,
    manager integer DEFAULT 0,
    tourneur integer DEFAULT 0
);


ALTER TABLE public.groupe OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: groupe_det; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE groupe_det (
    id integer,
    musicien integer
);


ALTER TABLE public.groupe_det OWNER TO nobody;

--
-- Name: groupe_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE groupe_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.groupe_id_seq OWNER TO nobody;

--
-- Name: groupe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE groupe_id_seq OWNED BY groupe.id;


--
-- Name: groupe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('groupe_id_seq', 3, true);


--
-- Name: guichet; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE guichet (
    banque character(5),
    code character(5),
    id integer NOT NULL,
    domiciliation character varying(32),
    bic character varying(11)
);


ALTER TABLE public.guichet OWNER TO nobody;

--
-- Name: idafaire; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idafaire
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idafaire OWNER TO nobody;

--
-- Name: idafaire; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idafaire', 1, false);


--
-- Name: idcategorieprof; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idcategorieprof
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idcategorieprof OWNER TO nobody;

--
-- Name: idcategorieprof; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idcategorieprof', 18, true);


--
-- Name: idcdrom; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idcdrom
    START WITH 490
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idcdrom OWNER TO nobody;

--
-- Name: idcdrom; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idcdrom', 490, false);


--
-- Name: idcommande; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idcommande
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idcommande OWNER TO nobody;

--
-- Name: idcommande; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idcommande', 4, true);


--
-- Name: idetab; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idetab
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idetab OWNER TO nobody;

--
-- Name: idetab; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idetab', 1, true);


--
-- Name: idforfait; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idforfait
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idforfait OWNER TO nobody;

--
-- Name: idforfait; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idforfait', 2, true);


--
-- Name: idinstrument; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idinstrument
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idinstrument OWNER TO nobody;

--
-- Name: idinstrument; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idinstrument', 55, true);


--
-- Name: idmajoration; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idmajoration
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idmajoration OWNER TO nobody;

--
-- Name: idmajoration; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idmajoration', 1, false);


--
-- Name: idmodule; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idmodule
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idmodule OWNER TO nobody;

--
-- Name: idmodule; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idmodule', 9, true);


--
-- Name: idmoduletype; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idmoduletype
    INCREMENT BY 1
    MAXVALUE 2147483647
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.idmoduletype OWNER TO nobody;

--
-- Name: idmoduletype; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idmoduletype', 14, true);


--
-- Name: idnote; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idnote
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idnote OWNER TO nobody;

--
-- Name: idnote; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idnote', 1, false);


--
-- Name: idper; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idper
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idper OWNER TO nobody;

--
-- Name: idper; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idper', 11, true);


--
-- Name: idpostit; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idpostit
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idpostit OWNER TO nobody;

--
-- Name: idpostit; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idpostit', 6, true);


--
-- Name: idsalle; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idsalle
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idsalle OWNER TO nobody;

--
-- Name: idsalle; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idsalle', 4, true);


--
-- Name: idsuivi; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE idsuivi
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.idsuivi OWNER TO nobody;

--
-- Name: idsuivi; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('idsuivi', 1, true);


--
-- Name: instrument; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE instrument (
    id integer NOT NULL,
    nom character varying(32)
);


ALTER TABLE public.instrument OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: journalcompta; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE journalcompta (
    id integer NOT NULL,
    code character varying(24) NOT NULL,
    libelle character varying(128),
    compte integer
);


ALTER TABLE public.journalcompta OWNER TO nobody;

--
-- Name: journalcompta_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE journalcompta_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.journalcompta_id_seq OWNER TO nobody;

--
-- Name: journalcompta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE journalcompta_id_seq OWNED BY journalcompta.id;


--
-- Name: journalcompta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('journalcompta_id_seq', 4, true);


SET default_with_oids = true;

--
-- Name: login; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE login (
    idper integer,
    login character(8),
    password character(8),
    profil integer
);


ALTER TABLE public.login OWNER TO nobody;

--
-- Name: maintenance; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE maintenance (
    jour date,
    personne character varying(16),
    niveau integer,
    texte text,
    fait boolean
);


ALTER TABLE public.maintenance OWNER TO nobody;

--
-- Name: majoration; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE majoration (
    id integer,
    mode character(32),
    pcent integer
);


ALTER TABLE public.majoration OWNER TO nobody;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE menu (
    id integer,
    nom character varying(64),
    libelle character varying(32)
);


ALTER TABLE public.menu OWNER TO nobody;

--
-- Name: menu2; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE menu2 (
    id integer,
    label character varying(50)
);


ALTER TABLE public.menu2 OWNER TO nobody;

--
-- Name: menuaccess; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE menuaccess (
    idper integer,
    idmenu integer,
    autorisation boolean
);


ALTER TABLE public.menuaccess OWNER TO nobody;

--
-- Name: menuprofil; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE menuprofil (
    idmenu integer,
    profil integer,
    auth boolean
);


ALTER TABLE public.menuprofil OWNER TO nobody;

--
-- Name: module; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE module (
    id integer NOT NULL,
    code character varying(10),
    titre character varying(64),
    prix_base numeric,
    taux_mensuel numeric,
    taux_trim numeric,
    unite integer
);


ALTER TABLE public.module OWNER TO nobody;

--
-- Name: module_compo; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE module_compo (
    module integer,
    mtype integer
);


ALTER TABLE public.module_compo OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: module_cours; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE module_cours (
    id smallint NOT NULL,
    idmodule integer NOT NULL,
    code smallint,
    duree integer DEFAULT 0
);


ALTER TABLE public.module_cours OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: module_type; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE module_type (
    id integer DEFAULT nextval('idmoduletype'::regclass) NOT NULL,
    code character varying(8),
    libelle character varying(128)
);


ALTER TABLE public.module_type OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: niveau; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE niveau (
    id smallint NOT NULL,
    code character(1),
    libelle character varying(128)
);


ALTER TABLE public.niveau OWNER TO nobody;

--
-- Name: niveau_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE niveau_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.niveau_id_seq OWNER TO nobody;

--
-- Name: niveau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE niveau_id_seq OWNED BY niveau.id;


--
-- Name: niveau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('niveau_id_seq', 1, false);


SET default_with_oids = true;

--
-- Name: note; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE note (
    id integer DEFAULT nextval('idnote'::regclass) NOT NULL,
    idper integer,
    texte text,
    ptype smallint
);


ALTER TABLE public.note OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: person_instrument; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE person_instrument (
    id integer NOT NULL,
    idx smallint,
    idper integer,
    instrument integer DEFAULT 0,
    ptype smallint
);


ALTER TABLE public.person_instrument OWNER TO nobody;

--
-- Name: person_instrument_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE person_instrument_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.person_instrument_id_seq OWNER TO nobody;

--
-- Name: person_instrument_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE person_instrument_id_seq OWNED BY person_instrument.id;


--
-- Name: person_instrument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('person_instrument_id_seq', 6, true);


SET default_with_oids = true;

--
-- Name: personne; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE personne (
    id integer DEFAULT nextval('idper'::regclass) NOT NULL,
    ptype smallint,
    nom character varying(32),
    prenom character varying(32),
    civilite character(4),
    droit_img boolean,
    organisation character varying(64) DEFAULT NULL::character varying
);


ALTER TABLE public.personne OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: plage; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE plage (
    id integer NOT NULL,
    idplanning integer,
    debut time without time zone,
    fin time without time zone,
    adherent integer,
    note integer
);


ALTER TABLE public.plage OWNER TO nobody;

--
-- Name: plage_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE plage_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.plage_id_seq OWNER TO nobody;

--
-- Name: plage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE plage_id_seq OWNED BY plage.id;


--
-- Name: plage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('plage_id_seq', 173, true);


--
-- Name: planning; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE planning (
    id integer NOT NULL,
    jour date,
    debut time without time zone,
    fin time without time zone,
    ptype integer,
    idper integer,
    action integer,
    lieux integer,
    note integer
);


ALTER TABLE public.planning OWNER TO nobody;

--
-- Name: planning_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE planning_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.planning_id_seq OWNER TO nobody;

--
-- Name: planning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE planning_id_seq OWNED BY planning.id;


--
-- Name: planning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('planning_id_seq', 181, true);


SET default_with_oids = true;

--
-- Name: salle; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE salle (
    id integer NOT NULL,
    nom character varying(24),
    fonction character varying(32),
    surf smallint,
    npers smallint,
    etablissement integer,
    active boolean,
    idtarif integer,
    idper integer,
    payeur integer,
    public boolean DEFAULT false
);


ALTER TABLE public.salle OWNER TO nobody;

--
-- Name: planningvue; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW planningvue AS
    SELECT pl.id, pl.jour, pl.debut, pl.fin, pl.action, p.id AS profid, p.prenom AS prenomprof, p.nom AS nomprof, s.id AS salleid, s.nom AS salle, c.id AS coursid, c.titre AS cours, c.ecole FROM planning pl, personne p, salle s, cours c, action a WHERE ((((pl.action = a.id) AND (a.cours = c.id)) AND (pl.lieux = s.id)) AND (pl.idper = p.id));


ALTER TABLE public.planningvue OWNER TO postgres;

--
-- Name: postit; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE postit (
    id integer,
    ptype integer,
    emet integer,
    dest integer,
    jour date,
    echeance date,
    texte character varying(256)
);


ALTER TABLE public.postit OWNER TO nobody;

--
-- Name: prof; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE prof (
    idper integer,
    diplome1 character varying(64),
    diplome2 character varying(64),
    diplome3 character varying(64),
    actif boolean
);


ALTER TABLE public.prof OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: reglement; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE reglement (
    id integer NOT NULL,
    mode character varying(4) NOT NULL
);


ALTER TABLE public.reglement OWNER TO nobody;

--
-- Name: reglement_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE reglement_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.reglement_id_seq OWNER TO nobody;

--
-- Name: reglement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE reglement_id_seq OWNED BY reglement.id;


--
-- Name: reglement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('reglement_id_seq', 6, true);


--
-- Name: remplacement; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE remplacement (
    id_etab integer NOT NULL,
    id_cours integer NOT NULL,
    id_prof integer NOT NULL,
    id_remplacant integer NOT NULL,
    jours character(7) DEFAULT '0000000'::bpchar,
    favori boolean DEFAULT false
);


ALTER TABLE public.remplacement OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: rib; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE rib (
    idper integer,
    etablissement character(5),
    guichet character(5),
    compte character(11),
    clerib character(2),
    guichetid integer,
    iban character varying(34)
);


ALTER TABLE public.rib OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: salarie; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE salarie (
    idper integer NOT NULL,
    insee character(15) NOT NULL,
    datenais date,
    lieunais character varying(128),
    guso character(10)
);


ALTER TABLE public.salarie OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: sallequip; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE sallequip (
    idsalle integer NOT NULL,
    libelle character varying(64) NOT NULL,
    qte integer,
    idx smallint
);


ALTER TABLE public.sallequip OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: siteweb; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE siteweb (
    idx integer NOT NULL,
    idper integer NOT NULL,
    url character varying,
    type integer DEFAULT 1,
    ptype smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.siteweb OWNER TO nobody;

--
-- Name: statut; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE statut (
    id smallint NOT NULL,
    code character(1),
    libelle character varying(128)
);


ALTER TABLE public.statut OWNER TO nobody;

--
-- Name: statut_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE statut_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.statut_id_seq OWNER TO nobody;

--
-- Name: statut_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE statut_id_seq OWNED BY statut.id;


--
-- Name: statut_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('statut_id_seq', 2, true);


--
-- Name: stylemus_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE stylemus_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.stylemus_id_seq OWNER TO nobody;

--
-- Name: stylemus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('stylemus_id_seq', 32, true);


--
-- Name: stylemus; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE stylemus (
    id integer DEFAULT nextval('stylemus_id_seq'::regclass) NOT NULL,
    libelle character varying(32)
);


ALTER TABLE public.stylemus OWNER TO nobody;

SET default_with_oids = true;

--
-- Name: suivi; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE suivi (
    id integer NOT NULL,
    texte text
);


ALTER TABLE public.suivi OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: tarifsalle; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE tarifsalle (
    id integer NOT NULL,
    libelle character varying(128) NOT NULL,
    type character varying(32) NOT NULL,
    hc numeric DEFAULT 0.0,
    hp numeric DEFAULT 0.0,
    plafond numeric DEFAULT 0.0,
    forfaithc numeric DEFAULT 0.0,
    forfaithp numeric DEFAULT 0.0
);


ALTER TABLE public.tarifsalle OWNER TO nobody;

--
-- Name: tarifsalle_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE tarifsalle_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tarifsalle_id_seq OWNER TO nobody;

--
-- Name: tarifsalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE tarifsalle_id_seq OWNED BY tarifsalle.id;


--
-- Name: tarifsalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('tarifsalle_id_seq', 4, true);


SET default_with_oids = true;

--
-- Name: telephone; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE telephone (
    idper integer,
    idx integer,
    numero character varying(24),
    typetel integer DEFAULT 1
);


ALTER TABLE public.telephone OWNER TO nobody;

SET default_with_oids = false;

--
-- Name: tiersproduit; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE tiersproduit (
    tiers integer NOT NULL,
    produit integer
);


ALTER TABLE public.tiersproduit OWNER TO nobody;

--
-- Name: trancheage; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE trancheage (
    id integer NOT NULL,
    agemin integer,
    agemax integer,
    nom character varying(32),
    code character(1)
);


ALTER TABLE public.trancheage OWNER TO nobody;

--
-- Name: trancheage_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE trancheage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;


ALTER TABLE public.trancheage_id_seq OWNER TO nobody;

--
-- Name: trancheage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE trancheage_id_seq OWNED BY trancheage.id;


--
-- Name: trancheage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('trancheage_id_seq', 1, false);


--
-- Name: tva; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE tva (
    id integer NOT NULL,
    pourcentage numeric
);


ALTER TABLE public.tva OWNER TO nobody;

--
-- Name: tva_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE tva_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tva_id_seq OWNER TO nobody;

--
-- Name: tva_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE tva_id_seq OWNED BY tva.id;


--
-- Name: tva_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('tva_id_seq', 5, true);


--
-- Name: typetel; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE typetel (
    id integer NOT NULL,
    type character varying(16) NOT NULL
);


ALTER TABLE public.typetel OWNER TO nobody;

--
-- Name: typetel_id_seq; Type: SEQUENCE; Schema: public; Owner: nobody
--

CREATE SEQUENCE typetel_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.typetel_id_seq OWNER TO nobody;

--
-- Name: typetel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nobody
--

ALTER SEQUENCE typetel_id_seq OWNED BY typetel.id;


--
-- Name: typetel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nobody
--

SELECT pg_catalog.setval('typetel_id_seq', 14, true);


SET default_with_oids = true;

--
-- Name: vacance; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE vacance (
    jour date,
    ptype integer,
    vid integer,
    libelle character(32)
);


ALTER TABLE public.vacance OWNER TO nobody;

--
-- Name: version; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE version (
    version character(8)
);


ALTER TABLE public.version OWNER TO nobody;

--
-- Name: ville; Type: TABLE; Schema: public; Owner: nobody; Tablespace: 
--

CREATE TABLE ville (
    cdp character(5),
    nom character varying(50)
);


ALTER TABLE public.ville OWNER TO nobody;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE action ALTER COLUMN id SET DEFAULT nextval('action_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE article ALTER COLUMN id SET DEFAULT nextval('article_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE carteabopersonne ALTER COLUMN id SET DEFAULT nextval('carteabopersonne_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE carteaborepet ALTER COLUMN id SET DEFAULT nextval('carteaborepet_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE categorie_siteweb ALTER COLUMN id SET DEFAULT nextval('categorie_siteweb_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE categorie_vacance ALTER COLUMN id SET DEFAULT nextval('categorie_vacance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE commande_cours ALTER COLUMN id SET DEFAULT nextval('commande_cours_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE commande_module ALTER COLUMN id SET DEFAULT nextval('commande_module_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE compte ALTER COLUMN id SET DEFAULT nextval('compte_id_seq'::regclass);


--
-- Name: oid; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE echeancier2 ALTER COLUMN oid SET DEFAULT nextval('echeancier2_oid_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE ecole ALTER COLUMN id SET DEFAULT nextval('ecole_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE groupe ALTER COLUMN id SET DEFAULT nextval('groupe_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE journalcompta ALTER COLUMN id SET DEFAULT nextval('journalcompta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE niveau ALTER COLUMN id SET DEFAULT nextval('niveau_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE person_instrument ALTER COLUMN id SET DEFAULT nextval('person_instrument_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE plage ALTER COLUMN id SET DEFAULT nextval('plage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE planning ALTER COLUMN id SET DEFAULT nextval('planning_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE reglement ALTER COLUMN id SET DEFAULT nextval('reglement_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE statut ALTER COLUMN id SET DEFAULT nextval('statut_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE tarifsalle ALTER COLUMN id SET DEFAULT nextval('tarifsalle_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE trancheage ALTER COLUMN id SET DEFAULT nextval('trancheage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE tva ALTER COLUMN id SET DEFAULT nextval('tva_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nobody
--

ALTER TABLE typetel ALTER COLUMN id SET DEFAULT nextval('typetel_id_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY action (id, cours, niveau, places, tage, statut) FROM stdin;
1	9	0	0	0	0
2	14	0	0	0	0
5	17	0	0	0	0
8	19	0	0	0	0
9	19	0	4	0	0
10	19	0	4	0	0
11	19	0	4	0	0
12	19	0	4	0	0
13	19	0	4	0	0
14	19	0	4	0	0
\.


--
-- Data for Name: adresse; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY adresse (idper, adr1, adr2, cdp, ville, archive) FROM stdin;
6	15 rue Salvador Allende		92240	MALAKOFF	f
\.


--
-- Data for Name: analytique; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY analytique (code, libelle, actif) FROM stdin;
EFORLOISIR	Extérieur formation loisir	t
AARPAREPAR	Tout à répartir	t
AFORLOISIR	Formation loisir à répartir	t
AFORPROFES	Formation pro à répartir	t
JENRAREPAR	Enregistrement à répartir	t
JFORLOISIR	Formation loisir	t
JFORPROFES	Formation pro	t
JREPLOISIR	Répétition loisir	t
JREPPROFES	Répétition pro	t
\.


--
-- Data for Name: article; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY article (id, designation, prix_u, id_tva, compte, standard) FROM stdin;
5	Adhésion p6 a6	10.0	1	7	f
6	Adhésion	10.0	1	7	f
\.


--
-- Data for Name: article_devis; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY article_devis (id_devis, id_article, quantite) FROM stdin;
\.


--
-- Data for Name: article_facture; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY article_facture (id_facture, id_echeancier, id_article, quantite) FROM stdin;
\.


--
-- Data for Name: atelier_ins; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY atelier_ins (id, adherent, instrument) FROM stdin;
\.


--
-- Data for Name: banque; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY banque (code, nom, multiguichet) FROM stdin;
14306	CREDIT AGRICOLE               	f
14406	CREDIT AGRICOLE               	f
15206	CREDIT AGRICOLE               	f
15589	CREDIT MUTUEL                 	f
16306	CREDIT AGRICOLE               	f
17515	CAISSE D'EPARGNE              	t
17695	CAISSE D'EPARGNE              	t
17865	CAISSE D'EPARGNE ECUREUIL     	t
17679	SBE                           	f
17806	CRCA DE SAONE ET LOIRE        	f
18106	CREDIT AGRICOLE               	f
12106	CREDIT AGRICOLE	f
19525	CAISSE D'EPARGNE              	f
30001	BANQUE DE FRANCE              	f
30002	CREDIT LYONNAIS               	f
30026	BANQUE PARIBAS                	f
30076	CREDIT DU NORD                	f
30086	SOCIETE GENERALE DE BANQUE    	f
30087	C.I.C. BANQUE SNVB            	f
15489	CREDIT MUTUEL	t
30047	CRÉDIT INDUSTRIEL DE L'OUEST	f
30118	BANQUE BEAU                  	f
30368	BANQUE HERVET                 	f
30568	BANQUE TRANSATLANTIQUE        	f
30588	BARCKLAYS                     	f
14806	CREDIT AGRICOLE	f
16606	CREDIT AGRICOLE	f
30828	L'EUROPEENNE DE BANQUE        	f
30938	UNION DE BANQUES A PARIS      	f
30998	BANQUE WORMS                  	f
40071	TRESOR PUBLIC                 	f
40168	BANQUE DE BRETAGNE            	f
41539	SOFINCO                       	f
42559	B F C C                       	f
42889	DEMACHY WORMS & CIE           	f
43649	BANQUE GENERALE DU COMMERCE   	f
50140	CREDIT MUNICIPAL DE PARIS     	f
18406	CREDIT AGRICOLE               	t
12135	CAISSE D EPARGNE	f
45499	CREDIT MUTUEL	t
13705	CAISSE D EPARGNE	f
41649	BANQUES FRANCO PORTUGUAISE	f
30066	C.I.C.	t
40978	BANQUE SAOPOLO	f
10067	SOCIETE GENERALE              	f
10071	TRESOR PUBLIC                 	f
15959	Credit Mutuel	f
11506	CREDIT AGRICOLE               	f
13707	CAISSE D'EPARGNE	f
12506	CREDIT AGRICOLE               	f
12579	SOTTOMAYOR                    	f
12706	CREDIT AGRICOLE               	f
12806	CREDIT AGRICOLE               	f
13506	CREDIT AGRICOLE               	f
13806	CREDIT AGRICOLE               	f
13906	CREDIT AGRICOLE               	f
30488	FORTIS	f
11406	CREDIT AGRICOLE	f
40458	DEXIA	f
12607	Banque Populaire	f
18206	CREDIT AGRICOLE	t
12206	CREDIT AGRICOLE	t
12406	CREDIT AGRICOLE	t
16806	CREDIT AGRICOLE	t
10278	CREDIT MUTUEL	f
13106	CREDIT AGRICOLE	f
41199	Banco Popular France	f
30788	BANQUE N. S. A.	f
12619	Caixa General de Despositos	f
10558	Banque Tarneaud	f
18715	CAISSE D'EPARGNE	f
13335	CAISSE D'EPARGNE	f
12548	AXA BANQUE DIRECTE	f
16506	CREDIT AGRICOLE DE L'OISE	f
12906	CREDIT AGRICOLE DU FINISTERE	f
15459	CREDIT MUTUEL	f
18306	CREDIT AGRICOLE DE NORMANDIE 	f
15829	CREDIT MUTUEL	f
18706	CREDIT AGRICOLE	f
15629	CREDIT MUTUEL	f
10507	BANQUE POPULAIRE	f
10206	CREDIT AGRICOLE DU NORD EST	f
16706	CREDIT AGRICOLE	f
18707	BANQUE POPULAIRE	t
10528	CIC	f
10207	BICS - BANQUE POPULAIRE	f
13306	CREDIT AGRICOLE	f
30003	SOCIETE GENERALE	t
10807	BANQUE POPULAIRE	f
11006	CREDIT AGRICOLE	f
11206	CREDIT AGRICOLE	f
11706	CREDIT AGRICOLE	f
16707	BANQUE POPULAIRE	f
30004	B.N.P. PARIBAS	f
17807	BANQUE POPULAIRE	f
16006	CREDIT AGRICOLE	f
30027	CIC	f
14506	credit agricole	f
44319	BPE	f
12225	CAISSE D EPARGNE	t
18645	CAISSE D'EPARGNE	t
20041	C.C.P.	t
30041	LA BANQUE POSTALE	t
30056	HSBC - CCF	t
10107	BRED / BANQUE POPULAIRE	f
19506	CREDIT AGRICOLE CENTRE OUEST	f
40618	BOURSORAMA BANQUE	f
13606	Crédit Agricole Ile et Vilaine	f
10011	LA BANQUE POSTALE	t
15135	CAISSE D'EPARGNE	f
30258	BTP BANQUE	f
14505	CAISSE D'EPARGNE	f
17206	CREDIT AGRICOLE ALSACE VOSGES	f
11425	CAISSE D'EPARGNE	f
16807	Banque Populaire des Alpes	f
13807	BANQUE POPULAIRE ATLANTIQUE	f
13135	Caisse d'Epargne	f
14559	ING DIRECT	f
\.


--
-- Data for Name: carteabopersonne; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY carteabopersonne (id, idper, idcarte, date_achat, restant) FROM stdin;
\.


--
-- Data for Name: carteaborepet; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY carteaborepet (id, libelle, montant, nbseances, dureemin) FROM stdin;
1	ZikPass	22.0	20	30
\.


--
-- Data for Name: categorie_prof; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY categorie_prof (id, nom) FROM stdin;
6	Musicien
3	Etudiant
4	Scolaire
5	Intermit. du spectacle
1	Cadre
8	Chomeur
9	Ouvrier
11	Agent de maitrise
7	Profession liberale
13	Sans profession
2	Employé
12	Autres
14	Commerce
15	Retraité
18	Artiste
17	Fonction publique
10	Agent administratif
\.


--
-- Data for Name: categorie_siteweb; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY categorie_siteweb (id, libelle) FROM stdin;
1	Perso
2	MySpace
3	Facebook
4	Twitter
\.


--
-- Data for Name: categorie_vacance; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY categorie_vacance (id, libelle) FROM stdin;
0	Sans vacances
1	Zone A
2	Zone B
3	Zone C
\.


--
-- Data for Name: cdpret; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY cdpret (cd, jour, adh) FROM stdin;
\.


--
-- Data for Name: cdrom; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY cdrom (id, artiste, album, label, ref, genre) FROM stdin;
\.


--
-- Data for Name: cdtitre; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY cdtitre (cd, numero, titre, interprete) FROM stdin;
\.


--
-- Data for Name: commande; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY commande (id, adh, payeur, creation, facture) FROM stdin;
1	7	7	2012-06-12	\N
2	6	6	2012-06-12	\N
4	7	7	2012-10-05	\N
\.


--
-- Data for Name: commande_cours; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY commande_cours (id, idcmd, module, idaction, debut, fin, datedebut, datefin, code) FROM stdin;
1	1	1	1	14:00:00	14:30:00	2012-09-17	2013-06-07	1
2	1	1	2	17:00:00	18:00:00	2012-09-17	2013-06-07	3
3	2	2	1	14:30:00	15:00:00	2012-09-17	2013-06-07	1
4	2	2	5	14:00:00	18:00:00	2012-09-17	2013-06-07	11
5	2	2	0	00:00:00	02:00:00	2012-09-17	2013-06-07	\N
7	4	3	8	14:00:00	15:00:00	2012-09-17	2013-06-07	1
\.


--
-- Data for Name: commande_module; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY commande_module (id, idcmd, module, prix, debut, fin, reglement, necheance, paiement) FROM stdin;
1	1	3	30000	2012-09-17	2013-06-07	CHQ 	3	TRIM
2	2	8	15000	2012-09-17	2013-06-07	CHQ 	3	TRIM
3	4	9	10000	2012-09-17	2013-06-07	CHQ 	3	TRIM
\.


--
-- Data for Name: compte; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY compte (id, numero, libelle, actif) FROM stdin;
1	7061100000	Cotisations aux cours	t
2	7061200000	Cotisations cours Form. Pro	t
3	7061300000	Ateliers/répétitions	t
4	7062100000	Autres usagers	t
5	7063000000	Autres prestations	t
6	7063100000	Droits d'entrée	t
9	7713000000	Dons	t
11	4110000100	Formation professionnelle / tiers	t
12	5120000000	Compte de banque	t
13	5300000000	Compte de caisse	t
7	7560000000	Adhésions	t
8	7063100020	Merchandising	f
10	7713000001	Dons mensuel	f
\.


--
-- Data for Name: comptepref; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY comptepref (id, idcompte, idanalytique) FROM stdin;
ADHÉSIONS	7	JFORLOISIR
COMPTE DE BANQUE	12	AARPAREPAR
COMPTE DE CAISSE	13	AARPAREPAR
FORMATION LOISIR	1	AFORLOISIR
FORMATION PROFESSIONNELLE	11	AFORPROFES
RÉPÉTITIONS	3	JREPLOISIR
ACTIVITES EXTERIEURES	1	AFORLOISIR
DIVERS/TIERS	11	JFORPROFES
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY config (clef, valeur) FROM stdin;
GestionAtelier	t
Compta.Prelevement.guichet	00000
Compta.Prelevement.emetteur	00000
Code.FP	              
FinHeureCreuse	17:00
Compta.CompteCheque	5300000000
ExportPath	C:\\Algem\\Transfert
Date.DebutPeriode	01-06-2011
Compta.CompteEspece	5120000000
Code.NAF	00000
Date.FinPeriode	31-08-2014
Ecole.par.defaut	0
Compta.Numero.Facture	0
Organisation.Cdp	00000
Compta.Prelevement.compte	00000000000
Compta.Prelevement.etablissement	00000
Organisation.Nom	Mon organisation
Date.FinAnnee	28-06-2014
GestionCours	t
GestionProf	t
Numero.SIRET	000 000 000 00000
Etablissement.par.defaut	3
Compta.BanqueCheque	CC
Date.DebutAnnee	16-09-2013
Compta.Numero.Piece	1
LogPath	C:\\Algem\\Journaux
Compta.BanqueEspece	CA
Compta.Prelevement.raison	ORGANISATION
Code.TVA	                       
Organisation.Ville	
Organisation.Adresse2	
Organisation.Adresse1	
\.


--
-- Data for Name: cours; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY cours (id, titre, libelle, nplaces, niveau, collectif, code, ecole, actif) FROM stdin;
9	PIANO	Piano Loisir    	0	0	f	1	0	t
10	GUITARE	Guitare Loisir  	0	0	f	1	0	t
19	BASSE	Basse co        	0	0	t	1	0	t
15	JEU EN GROUPE	Jeu en groupe   	0	0	t	3	0	t
14	AT JAZZ 1H	At. jazz 1h     	0	0	t	3	0	t
16	AT JAZZ 2H	At. Jazz 2h     	0	0	t	3	0	t
17	INITIATION AU JAZZ	At. dec. jazz   	0	0	t	11	0	t
12	SOLFEGE DEBUTANT	Solfège déb. L  	0	0	t	2	0	t
13	HARMONIE FOR PRO	Harmonie pro 1  	0	0	t	2	0	t
\.


--
-- Data for Name: devis; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY devis (numero, date_emission, etablissement, emetteur, debiteur, prestation, reference, adherent, editable) FROM stdin;
\.


--
-- Data for Name: droits; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY droits (idper, nomtable, lecture, insertion, modification, suppression) FROM stdin;
\.


--
-- Data for Name: echeancier2; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY echeancier2 (oid, echeance, payeur, adherent, commande, reglement, libelle, montant, piece, ecole, compte, paye, transfert, monnaie, analytique, facture) FROM stdin;
\.


--
-- Data for Name: ecole; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY ecole (id, nom) FROM stdin;
0	DEF
\.


--
-- Data for Name: eleve; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY eleve (idper, profession, datenais, payeur, nadhesions, pratique, niveau, archiv) FROM stdin;
7	aucun	1985-05-28	7	1	0	1	\N
6	aucun	1980-03-03	6	2	0	0	\N
\.


--
-- Data for Name: email; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY email (idper, email, archive, idx) FROM stdin;
6	marcel.dupont@fai.fr	f	0
\.


--
-- Data for Name: facture; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY facture (numero, date_emission, etablissement, emetteur, debiteur, prestation, reference, adherent, acompte) FROM stdin;
\.


--
-- Data for Name: groupe; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY groupe (id, nom, style, referent, manager, tourneur) FROM stdin;
3	GROUPE DEMO 2B	14	0	0	0
2	GROUPE DEMO	24	6	0	0
\.


--
-- Data for Name: groupe_det; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY groupe_det (id, musicien) FROM stdin;
2	6
2	7
\.


--
-- Data for Name: guichet; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY guichet (banque, code, id, domiciliation, bic) FROM stdin;
15459	37158	27	CM Belleme	\N
\.


--
-- Data for Name: instrument; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY instrument (id, nom) FROM stdin;
1	Basse
2	Batterie
3	Cello
4	Chant
5	Clarinette
6	Clavier
7	Contrebasse
8	Flûte
9	Flûte bec
10	Flûte trav
11	Guitare
12	Harmonica
13	Percussion
14	Piano
15	Sax
16	Sax alto
19	Sax ténor
20	Synthé
21	Trombone
22	Trompette
23	Violon
24	Voix
17	Sax baryton
26	Vibraphone
27	Djembé
28	M.A.O.
29	Alto
30	Steel drum
31	Néant
35	Oud
34	DJ - Mix
36	Harpe
37	Tabla
38	Balafon
39	Tech. son
41	Timbales
42	Tuba
18	Sax soprano
43	Accordéon diatonique
25	Accordéon chromatique
44	Soubassophone
40	Congas
45	Guimbarde
46	Violoncelle
47	Culture
48	Culture rythmique
50	Théorie
51	Cor
53	Rythme oreille
54	Atelier
55	Piano complémentaire
49	Harmonie
52	Technique Vocale
0	
\.


--
-- Data for Name: journalcompta; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY journalcompta (id, code, libelle, compte) FROM stdin;
1	VE	ventes	11
2	CP	postal	5
3	CC	Crédit	12
4	CA	Achat	13
\.


--
-- Data for Name: login; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY login (idper, login, password, profil) FROM stdin;
1	admin   	admin   	4
\.


--
-- Data for Name: maintenance; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY maintenance (jour, personne, niveau, texte, fait) FROM stdin;
\.


--
-- Data for Name: majoration; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY majoration (id, mode, pcent) FROM stdin;
\.


--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY menu (id, nom, libelle) FROM stdin;
1	ContactConsultation	\N
2	ContactCreation	\N
3	ContactSuppression	\N
11	AdherentConsultation	\N
12	AdherentCreation	\N
13	AdherentSuppression	\N
16	AdherentContact	\N
15	InscriptionAdherentRepetition	\N
14	InscriptionAdherentCours	\N
21	EnseignantConsultation	\N
22	EnseignantCreation	\N
24	EnseignantContact	\N
31	PayeurConsultation	\N
32	PayeurCreation	\N
33	PayeurSuppression	\N
34	PayeurPrelevement	\N
41	GroupeConsultation	\N
42	GroupeCreation	\N
43	GroupeSuppression	\N
44	GroupeForfaitRepetition	\N
51	AgenceBancaireConsultation	\N
52	AgenceBancaireCreation	\N
53	AgenceBancaireSuppression	\N
61	EtablissementConsultation	\N
62	EtablissementCreation	\N
71	SalleConsultation	\N
72	SalleCreation	\N
81	AtelierConsultation	\N
82	AtelierCreation	\N
101	GestionDroits	\N
102	GestionConnexion	\N
23	EnseignantSuppression	\N
\.


--
-- Data for Name: menu2; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY menu2 (id, label) FROM stdin;
1	Contact.reading.auth
2	Contact.creation.auth
3	Contact.suppression.auth
11	Member.reading.auth
12	Member.creation.auth
13	Member.suppression.auth
15	Member.rehearsal.scheduling.auth
14	Member.course.enrolment.auth
21	Teacher.reading.auth
22	Teacher.creation.auth
31	Payer.reading.auth
32	Payer.creation.auth
33	Payer.suppression.auth
34	Payer.debiting.auth
41	Group.reading.auth
42	Group.creation.auth
43	Group.suppression.auth
44	Group.pass.scheduling.auth
51	Bank.branch.reading.auth
52	Bank.branch.creation.auth
53	Bank.branch.suppression.auth
61	Establishment.reading.auth
62	Establishment.creation.auth
71	Room.reading.auth
72	Room.creation.auth
81	Workshop.reading.auth
82	Workshop.creation.auth
101	Rights.management.auth
102	Connection.management.auth
23	Teacher.suppression.auth
105	Login.creation.auth
106	Person.bank.editing.auth
107	Person.rehearsal.scheduling.auth
108	Person.pass.scheduling.auth
111	Person.month.schedule.opening.auth
113	Course.suppression.auth
112	Replacement.config.auth
114	Rehearsal.card.editing.auth
115	Rehearsal.history.auth
116	Color.preferences.auth
117	Account.preferences.auth
122	Configuration.management.auth
123	Room.suppression.auth
124	Accounting.management.auth
125	Standing.order.export.auth
126	Accounting.global.schedule.auth
127	Accounting.hours.export.auth
128	Accounting.account.config.auth
129	Accounting.cost.account.config.auth
130	Accounting.journal.config.auth
133	Accounting.hours.stat.auth
134	Course.schedule.modification.auth
135	Schedule.suppression.auth
136	Invoice.history.auth
137	Invoice.creation.auth
138	Invoice.modification.auth
139	Quotation.history.auth
140	Quotation.creation.auth
141	Quotation.modification.auth
131	Accounting.transfer.auth
132	Accounting.document.transfer.auth
63	Establishment.suppression.auth
\.


--
-- Data for Name: menuaccess; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY menuaccess (idper, idmenu, autorisation) FROM stdin;
1	101	t
1	102	t
1	11	t
1	12	t
1	13	t
1	14	t
1	15	t
1	1	t
1	21	t
1	22	t
1	23	t
1	2	t
1	31	t
1	32	t
1	33	t
1	34	t
1	3	t
1	41	t
1	42	t
1	43	t
1	44	t
1	51	t
1	52	t
1	53	t
1	61	t
1	62	t
1	71	t
1	72	t
1	81	t
1	82	t
1	105	t
1	106	t
1	107	t
1	108	t
1	111	t
1	112	t
1	113	t
1	114	t
1	115	t
1	116	t
1	117	t
1	122	t
1	123	t
1	125	t
1	126	t
1	127	t
1	128	t
1	129	t
1	130	t
1	131	t
1	132	t
1	133	t
1	124	t
1	134	t
1	135	t
1	136	t
1	137	t
1	138	t
1	139	t
1	140	t
1	141	t
1	63	t
\.


--
-- Data for Name: menuprofil; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY menuprofil (idmenu, profil, auth) FROM stdin;
1	4	t
2	4	t
3	4	t
11	4	t
12	4	t
13	4	t
21	4	t
22	4	t
23	4	t
31	4	t
32	4	t
33	4	t
34	4	t
41	4	t
42	4	t
43	4	t
51	4	t
52	4	t
53	4	t
61	4	t
62	4	t
71	4	t
72	4	t
101	4	t
102	4	t
1	1	t
2	1	f
3	1	f
11	1	t
12	1	f
13	1	f
21	1	t
22	1	f
23	1	f
31	1	f
32	1	t
33	1	f
34	1	f
41	1	t
42	1	f
43	1	f
51	1	t
52	1	f
53	1	f
61	1	t
62	1	f
71	1	t
72	1	f
101	1	f
102	1	f
1	2	t
2	2	f
3	2	f
11	2	t
12	2	f
13	2	f
21	2	t
22	2	f
23	2	f
31	2	f
32	2	t
33	2	f
34	2	f
41	2	t
42	2	f
43	2	f
51	2	t
52	2	f
53	2	f
61	2	t
62	2	f
71	2	t
72	2	f
101	2	f
102	2	f
1	3	t
2	3	f
3	3	f
11	3	t
12	3	f
13	3	f
21	3	t
22	3	f
23	3	f
31	3	f
32	3	t
33	3	f
34	3	f
41	3	t
42	3	f
43	3	f
51	3	t
52	3	f
53	3	f
61	3	t
62	3	f
71	3	t
72	3	f
101	3	f
102	3	f
14	1	t
15	1	t
44	1	t
14	2	t
15	2	t
44	2	t
14	3	t
15	3	t
44	3	t
14	4	t
15	4	t
44	4	t
81	1	t
82	1	t
81	2	t
82	2	t
81	3	t
82	3	t
81	4	t
82	4	t
105	4	t
106	4	t
107	4	t
108	4	t
111	4	t
105	1	f
106	1	t
107	1	t
108	1	t
111	1	t
105	0	f
106	0	f
107	0	f
108	0	f
111	0	t
105	2	f
106	2	f
107	2	f
108	2	f
111	2	t
105	3	f
106	3	f
107	3	f
108	3	f
111	3	t
112	4	t
112	1	f
112	0	f
112	2	f
112	3	f
113	4	t
113	1	f
113	0	f
113	2	f
113	3	f
114	4	t
114	1	t
114	0	t
114	2	t
114	3	t
115	0	t
115	1	t
115	2	t
115	3	t
115	4	t
116	0	f
116	1	f
116	2	f
116	3	f
116	4	t
117	0	f
117	1	f
117	2	f
117	3	f
117	4	t
122	0	f
122	1	f
122	2	f
122	3	f
122	4	t
123	0	f
123	1	f
123	2	f
123	4	t
123	3	f
124	0	f
124	2	f
124	3	f
124	4	t
125	0	f
125	1	f
125	2	f
125	3	f
125	4	t
126	0	f
126	1	f
126	2	f
126	3	f
126	4	t
127	0	f
127	1	t
127	2	f
127	3	f
127	4	t
128	0	f
128	1	f
128	2	f
128	3	f
128	4	t
129	0	f
129	1	f
129	2	f
129	3	f
129	4	t
130	0	f
130	1	f
130	2	f
130	3	f
130	4	t
131	0	f
131	1	f
131	2	f
131	3	f
131	4	t
132	0	f
132	1	f
132	2	f
132	3	f
132	4	t
133	0	f
133	1	f
133	2	f
133	3	f
133	4	t
124	1	t
134	0	f
134	1	f
134	2	f
134	3	f
134	4	t
135	0	f
135	1	f
135	2	f
135	3	f
135	4	t
1	0	t
2	0	f
3	0	f
11	0	t
12	0	f
13	0	f
14	0	f
15	0	f
21	0	t
22	0	f
23	0	f
31	0	f
32	0	f
33	0	f
34	0	f
41	0	t
42	0	f
43	0	f
44	0	f
51	0	t
52	0	f
53	0	f
61	0	t
62	0	f
71	0	t
72	0	f
81	0	t
82	0	f
101	0	f
102	0	f
136	0	f
136	1	t
136	2	f
136	3	f
136	4	t
137	0	f
137	1	f
137	2	f
137	3	f
137	4	t
138	0	f
138	1	f
138	2	f
138	3	f
138	4	t
139	0	f
139	1	t
139	2	f
139	3	f
139	4	t
140	0	f
140	1	f
140	2	f
140	3	f
140	4	t
141	0	f
141	1	f
141	2	f
141	3	f
141	4	t
63	0	f
63	1	f
63	2	f
63	3	f
63	4	t
\.


--
-- Data for Name: module; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY module (id, code, titre, prix_base, taux_mensuel, taux_trim, unite) FROM stdin;
5	P	(P) Inst. 1h	250.0	0.0	0.0	0
3	L	(L) Inst. 30mn + Atelier 1h	300.0	0.0	0.0	0
4	L	(L) Inst. 30mn + Atelier 2h	350.0	0.0	0.0	0
2	L	(L) Instrument 45mn	250.0	0.0	0.0	0
1	L	(L) Instrument 30mn	200.0	0.0	0.0	0
6	P	(P) Inst. 1h + Atelier 2h	350.0	0.0	0.0	0
7	L	(L) Inst. 30mn + F.M.	200.0	0.0	0.0	0
8	L	(L) Inst. 30mn + At. découverte	150.0	0.0	0.0	0
9	L	(L) Inst 60 mn	100.0	0.0	0.0	0
\.


--
-- Data for Name: module_compo; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY module_compo (module, mtype) FROM stdin;
2	3
2	2
1	1
1	2
4	2
4	4
5	2
5	4
6	1
6	4
7	2
8	2
8	2
8	1
8	3
9	5
10	6
10	2
11	7
12	4
12	2
13	1
13	4
13	2
14	1
26	8
\.


--
-- Data for Name: module_cours; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY module_cours (id, idmodule, code, duree) FROM stdin;
0	1	1	30
0	2	1	45
0	3	1	30
0	4	1	30
0	5	1	60
0	6	1	60
0	7	1	30
0	8	1	30
0	9	1	60
1	3	3	60
1	4	3	120
1	6	3	120
1	7	2	60
1	8	11	0
\.


--
-- Data for Name: module_type; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY module_type (id, code, libelle) FROM stdin;
11	ATP	Atelier Ponctuel
0		
1	INST	Cours instrumental
2	FM	Formation musicale
9	EXT	Cours extérieur
3	AT	Atelier
7	FP	Formation professionnelle
\.


--
-- Data for Name: niveau; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY niveau (id, code, libelle) FROM stdin;
0	-	Aucun
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY note (id, idper, texte, ptype) FROM stdin;
\.


--
-- Data for Name: person_instrument; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY person_instrument (id, idx, idper, instrument, ptype) FROM stdin;
1	0	6	14	1
2	0	7	14	1
3	1	7	11	1
4	0	8	14	2
5	0	6	14	3
6	0	7	11	3
\.


--
-- Data for Name: personne; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY personne (id, ptype, nom, prenom, civilite, droit_img, organisation) FROM stdin;
1	1	ADMINISTRATEUR		M   	f	\N
0	1	a definir	voir	    	t	\N
3	5	ETABLISSEMENT		    	f	\N
5	4	SALLE 2		    	f	\N
4	4	SALLE 1		    	f	\N
7	1	DURAND	Elise	Mlle	t	\N
8	1	MONPROF	Daniel	M   	t	\N
6	1	DUPONT	Marcel	M   	t	\N
\.


--
-- Data for Name: plage; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY plage (id, idplanning, debut, fin, adherent, note) FROM stdin;
1	2	14:00:00	14:30:00	7	0
2	3	14:00:00	14:30:00	7	0
3	4	14:00:00	14:30:00	7	0
4	5	14:00:00	14:30:00	7	0
5	6	14:00:00	14:30:00	7	0
6	7	14:00:00	14:30:00	7	0
7	8	14:00:00	14:30:00	7	0
8	9	14:00:00	14:30:00	7	0
9	10	14:00:00	14:30:00	7	0
10	11	14:00:00	14:30:00	7	0
11	12	14:00:00	14:30:00	7	0
12	13	14:00:00	14:30:00	7	0
13	14	14:00:00	14:30:00	7	0
14	15	14:00:00	14:30:00	7	0
15	16	14:00:00	14:30:00	7	0
16	17	14:00:00	14:30:00	7	0
17	18	14:00:00	14:30:00	7	0
18	19	14:00:00	14:30:00	7	0
19	20	14:00:00	14:30:00	7	0
20	21	14:00:00	14:30:00	7	0
21	22	14:00:00	14:30:00	7	0
22	23	14:00:00	14:30:00	7	0
23	24	14:00:00	14:30:00	7	0
24	25	14:00:00	14:30:00	7	0
25	26	14:00:00	14:30:00	7	0
26	27	14:00:00	14:30:00	7	0
27	28	14:00:00	14:30:00	7	0
28	29	14:00:00	14:30:00	7	0
29	30	17:00:00	18:00:00	7	0
30	31	17:00:00	18:00:00	7	0
31	32	17:00:00	18:00:00	7	0
32	33	17:00:00	18:00:00	7	0
33	34	17:00:00	18:00:00	7	0
34	35	17:00:00	18:00:00	7	0
35	36	17:00:00	18:00:00	7	0
36	37	17:00:00	18:00:00	7	0
37	38	17:00:00	18:00:00	7	0
38	39	17:00:00	18:00:00	7	0
39	40	17:00:00	18:00:00	7	0
40	41	17:00:00	18:00:00	7	0
41	42	17:00:00	18:00:00	7	0
42	43	17:00:00	18:00:00	7	0
43	44	17:00:00	18:00:00	7	0
44	45	17:00:00	18:00:00	7	0
45	46	17:00:00	18:00:00	7	0
46	47	17:00:00	18:00:00	7	0
47	48	17:00:00	18:00:00	7	0
48	49	17:00:00	18:00:00	7	0
49	50	17:00:00	18:00:00	7	0
50	51	17:00:00	18:00:00	7	0
51	52	17:00:00	18:00:00	7	0
52	53	17:00:00	18:00:00	7	0
53	54	17:00:00	18:00:00	7	0
54	55	17:00:00	18:00:00	7	0
55	56	17:00:00	18:00:00	7	0
56	57	17:00:00	18:00:00	7	0
57	2	14:30:00	15:00:00	6	0
58	3	14:30:00	15:00:00	6	0
59	4	14:30:00	15:00:00	6	0
60	5	14:30:00	15:00:00	6	0
61	6	14:30:00	15:00:00	6	0
62	7	14:30:00	15:00:00	6	0
63	8	14:30:00	15:00:00	6	0
64	9	14:30:00	15:00:00	6	0
65	10	14:30:00	15:00:00	6	0
66	11	14:30:00	15:00:00	6	0
67	12	14:30:00	15:00:00	6	0
68	13	14:30:00	15:00:00	6	0
69	14	14:30:00	15:00:00	6	0
70	15	14:30:00	15:00:00	6	0
71	16	14:30:00	15:00:00	6	0
72	17	14:30:00	15:00:00	6	0
73	18	14:30:00	15:00:00	6	0
74	19	14:30:00	15:00:00	6	0
75	20	14:30:00	15:00:00	6	0
76	21	14:30:00	15:00:00	6	0
77	22	14:30:00	15:00:00	6	0
78	23	14:30:00	15:00:00	6	0
79	24	14:30:00	15:00:00	6	0
80	25	14:30:00	15:00:00	6	0
81	26	14:30:00	15:00:00	6	0
82	27	14:30:00	15:00:00	6	0
83	28	14:30:00	15:00:00	6	0
84	29	14:30:00	15:00:00	6	0
85	59	14:00:00	18:00:00	6	0
86	2	15:30:00	15:45:00	0	0
87	3	15:30:00	15:45:00	0	0
88	4	15:30:00	15:45:00	0	0
89	5	15:30:00	15:45:00	0	0
90	6	15:30:00	15:45:00	0	0
91	7	15:30:00	15:45:00	0	0
92	8	15:30:00	15:45:00	0	0
93	9	15:30:00	15:45:00	0	0
94	10	15:30:00	15:45:00	0	0
95	11	15:30:00	15:45:00	0	0
96	12	15:30:00	15:45:00	0	0
97	13	15:30:00	15:45:00	0	0
98	14	15:30:00	15:45:00	0	0
99	15	15:30:00	15:45:00	0	0
100	16	15:30:00	15:45:00	0	0
101	17	15:30:00	15:45:00	0	0
102	18	15:30:00	15:45:00	0	0
103	19	15:30:00	15:45:00	0	0
104	20	15:30:00	15:45:00	0	0
105	21	15:30:00	15:45:00	0	0
106	22	15:30:00	15:45:00	0	0
107	23	15:30:00	15:45:00	0	0
108	24	15:30:00	15:45:00	0	0
109	25	15:30:00	15:45:00	0	0
110	26	15:30:00	15:45:00	0	0
111	27	15:30:00	15:45:00	0	0
112	28	15:30:00	15:45:00	0	0
113	29	15:30:00	15:45:00	0	0
144	68	14:00:00	15:00:00	7	0
145	69	14:00:00	15:00:00	7	0
146	70	14:00:00	15:00:00	7	0
147	71	14:00:00	15:00:00	7	0
148	72	14:00:00	15:00:00	7	0
149	73	14:00:00	15:00:00	7	0
150	74	14:00:00	15:00:00	7	0
151	75	14:00:00	15:00:00	7	0
152	76	14:00:00	15:00:00	7	0
153	77	14:00:00	15:00:00	7	0
154	78	14:00:00	15:00:00	7	0
155	79	14:00:00	15:00:00	7	0
156	80	14:00:00	15:00:00	7	0
157	81	14:00:00	15:00:00	7	0
158	82	14:00:00	15:00:00	7	0
159	83	14:00:00	15:00:00	7	0
160	84	14:00:00	15:00:00	7	0
161	85	14:00:00	15:00:00	7	0
162	86	14:00:00	15:00:00	7	0
163	87	14:00:00	15:00:00	7	0
164	88	14:00:00	15:00:00	7	0
165	89	14:00:00	15:00:00	7	0
166	90	14:00:00	15:00:00	7	0
167	91	14:00:00	15:00:00	7	0
168	92	14:00:00	15:00:00	7	0
169	93	14:00:00	15:00:00	7	0
170	94	14:00:00	15:00:00	7	0
171	95	14:00:00	15:00:00	7	0
172	96	14:00:00	15:00:00	7	0
173	97	14:00:00	15:00:00	7	0
\.


--
-- Data for Name: planning; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY planning (id, jour, debut, fin, ptype, idper, action, lieux, note) FROM stdin;
59	2012-09-22	14:00:00	18:00:00	5	8	5	1	0
60	2012-09-17	10:30:00	11:30:00	4	6	6	2	0
61	2012-09-17	18:00:00	20:00:00	3	2	7	2	0
62	2012-09-24	18:00:00	20:00:00	3	2	7	2	0
63	2012-10-01	18:00:00	20:00:00	3	2	7	2	0
64	2012-10-08	18:00:00	20:00:00	3	2	7	2	0
65	2012-10-15	18:00:00	20:00:00	3	2	7	2	0
66	2012-10-22	18:00:00	20:00:00	3	2	7	2	0
67	2012-10-29	18:00:00	20:00:00	3	2	7	2	0
2	2012-09-17	14:00:00	17:00:00	1	8	1	1	0
3	2012-09-24	14:00:00	17:00:00	1	8	1	1	0
4	2012-10-01	14:00:00	17:00:00	1	8	1	1	0
5	2012-10-08	14:00:00	17:00:00	1	8	1	1	0
6	2012-10-15	14:00:00	17:00:00	1	8	1	1	0
7	2012-10-22	14:00:00	17:00:00	1	8	1	1	0
8	2012-11-12	14:00:00	17:00:00	1	8	1	1	0
9	2012-11-19	14:00:00	17:00:00	1	8	1	1	0
10	2012-11-26	14:00:00	17:00:00	1	8	1	1	0
11	2012-12-03	14:00:00	17:00:00	1	8	1	1	0
12	2012-12-10	14:00:00	17:00:00	1	8	1	1	0
13	2012-12-17	14:00:00	17:00:00	1	8	1	1	0
14	2013-01-07	14:00:00	17:00:00	1	8	1	1	0
15	2013-01-14	14:00:00	17:00:00	1	8	1	1	0
16	2013-01-21	14:00:00	17:00:00	1	8	1	1	0
17	2013-01-28	14:00:00	17:00:00	1	8	1	1	0
18	2013-02-04	14:00:00	17:00:00	1	8	1	1	0
19	2013-02-11	14:00:00	17:00:00	1	8	1	1	0
20	2013-03-04	14:00:00	17:00:00	1	8	1	1	0
21	2013-03-11	14:00:00	17:00:00	1	8	1	1	0
22	2013-03-18	14:00:00	17:00:00	1	8	1	1	0
23	2013-03-25	14:00:00	17:00:00	1	8	1	1	0
24	2013-04-08	14:00:00	17:00:00	1	8	1	1	0
25	2013-04-29	14:00:00	17:00:00	1	8	1	1	0
26	2013-05-06	14:00:00	17:00:00	1	8	1	1	0
27	2013-05-13	14:00:00	17:00:00	1	8	1	1	0
28	2013-05-27	14:00:00	17:00:00	1	8	1	1	0
29	2013-06-03	14:00:00	17:00:00	1	8	1	1	0
30	2012-09-17	17:00:00	18:00:00	1	8	2	1	0
31	2012-09-24	17:00:00	18:00:00	1	8	2	1	0
32	2012-10-01	17:00:00	18:00:00	1	8	2	1	0
33	2012-10-08	17:00:00	18:00:00	1	8	2	1	0
34	2012-10-15	17:00:00	18:00:00	1	8	2	1	0
35	2012-10-22	17:00:00	18:00:00	1	8	2	1	0
36	2012-11-12	17:00:00	18:00:00	1	8	2	1	0
37	2012-11-19	17:00:00	18:00:00	1	8	2	1	0
38	2012-11-26	17:00:00	18:00:00	1	8	2	1	0
39	2012-12-03	17:00:00	18:00:00	1	8	2	1	0
40	2012-12-10	17:00:00	18:00:00	1	8	2	1	0
41	2012-12-17	17:00:00	18:00:00	1	8	2	1	0
42	2013-01-07	17:00:00	18:00:00	1	8	2	1	0
43	2013-01-14	17:00:00	18:00:00	1	8	2	1	0
44	2013-01-21	17:00:00	18:00:00	1	8	2	1	0
45	2013-01-28	17:00:00	18:00:00	1	8	2	1	0
46	2013-02-04	17:00:00	18:00:00	1	8	2	1	0
47	2013-02-11	17:00:00	18:00:00	1	8	2	1	0
48	2013-03-04	17:00:00	18:00:00	1	8	2	1	0
49	2013-03-11	17:00:00	18:00:00	1	8	2	1	0
50	2013-03-18	17:00:00	18:00:00	1	8	2	1	0
51	2013-03-25	17:00:00	18:00:00	1	8	2	1	0
52	2013-04-08	17:00:00	18:00:00	1	8	2	1	0
53	2013-04-29	17:00:00	18:00:00	1	8	2	1	0
54	2013-05-06	17:00:00	18:00:00	1	8	2	1	0
55	2013-05-13	17:00:00	18:00:00	1	8	2	1	0
56	2013-05-27	17:00:00	18:00:00	1	8	2	1	0
57	2013-06-03	17:00:00	18:00:00	1	8	2	1	0
68	2012-09-18	14:00:00	15:00:00	1	8	8	1	0
69	2012-09-25	14:00:00	15:00:00	1	8	8	1	0
70	2012-10-02	14:00:00	15:00:00	1	8	8	1	0
71	2012-10-09	14:00:00	15:00:00	1	8	8	1	0
72	2012-10-16	14:00:00	15:00:00	1	8	8	1	0
73	2012-10-23	14:00:00	15:00:00	1	8	8	1	0
74	2012-11-13	14:00:00	15:00:00	1	8	8	1	0
75	2012-11-20	14:00:00	15:00:00	1	8	8	1	0
76	2012-11-27	14:00:00	15:00:00	1	8	8	1	0
77	2012-12-04	14:00:00	15:00:00	1	8	8	1	0
78	2012-12-11	14:00:00	15:00:00	1	8	8	1	0
79	2012-12-18	14:00:00	15:00:00	1	8	8	1	0
80	2013-01-08	14:00:00	15:00:00	1	8	8	1	0
81	2013-01-15	14:00:00	15:00:00	1	8	8	1	0
82	2013-01-22	14:00:00	15:00:00	1	8	8	1	0
83	2013-01-29	14:00:00	15:00:00	1	8	8	1	0
84	2013-02-05	14:00:00	15:00:00	1	8	8	1	0
85	2013-02-12	14:00:00	15:00:00	1	8	8	1	0
86	2013-03-05	14:00:00	15:00:00	1	8	8	1	0
87	2013-03-12	14:00:00	15:00:00	1	8	8	1	0
88	2013-03-19	14:00:00	15:00:00	1	8	8	1	0
89	2013-03-26	14:00:00	15:00:00	1	8	8	1	0
90	2013-04-02	14:00:00	15:00:00	1	8	8	1	0
91	2013-04-09	14:00:00	15:00:00	1	8	8	1	0
92	2013-04-30	14:00:00	15:00:00	1	8	8	1	0
93	2013-05-07	14:00:00	15:00:00	1	8	8	1	0
94	2013-05-14	14:00:00	15:00:00	1	8	8	1	0
95	2013-05-21	14:00:00	15:00:00	1	8	8	1	0
96	2013-05-28	14:00:00	15:00:00	1	8	8	1	0
97	2013-06-04	14:00:00	15:00:00	1	8	8	1	0
98	2012-09-19	14:00:00	14:45:00	1	8	9	2	0
99	2012-10-03	14:00:00	14:45:00	1	8	9	2	0
100	2012-10-17	14:00:00	14:45:00	1	8	9	2	0
101	2012-11-14	14:00:00	14:45:00	1	8	9	2	0
102	2012-11-28	14:00:00	14:45:00	1	8	9	2	0
103	2012-12-12	14:00:00	14:45:00	1	8	9	2	0
104	2013-01-09	14:00:00	14:45:00	1	8	9	2	0
105	2013-01-23	14:00:00	14:45:00	1	8	9	2	0
106	2013-02-06	14:00:00	14:45:00	1	8	9	2	0
107	2013-03-06	14:00:00	14:45:00	1	8	9	2	0
108	2013-03-20	14:00:00	14:45:00	1	8	9	2	0
109	2013-04-03	14:00:00	14:45:00	1	8	9	2	0
110	2013-05-15	14:00:00	14:45:00	1	8	9	2	0
111	2013-05-29	14:00:00	14:45:00	1	8	9	2	0
112	2012-09-19	15:00:00	15:45:00	1	8	10	2	0
113	2012-10-03	15:00:00	15:45:00	1	8	10	2	0
114	2012-10-17	15:00:00	15:45:00	1	8	10	2	0
115	2012-11-14	15:00:00	15:45:00	1	8	10	2	0
116	2012-11-28	15:00:00	15:45:00	1	8	10	2	0
117	2012-12-12	15:00:00	15:45:00	1	8	10	2	0
118	2013-01-09	15:00:00	15:45:00	1	8	10	2	0
119	2013-01-23	15:00:00	15:45:00	1	8	10	2	0
120	2013-02-06	15:00:00	15:45:00	1	8	10	2	0
121	2013-03-06	15:00:00	15:45:00	1	8	10	2	0
122	2013-03-20	15:00:00	15:45:00	1	8	10	2	0
123	2013-04-03	15:00:00	15:45:00	1	8	10	2	0
124	2013-05-15	15:00:00	15:45:00	1	8	10	2	0
125	2013-05-29	15:00:00	15:45:00	1	8	10	2	0
126	2012-09-19	16:00:00	16:45:00	1	8	11	2	0
127	2012-10-03	16:00:00	16:45:00	1	8	11	2	0
128	2012-10-17	16:00:00	16:45:00	1	8	11	2	0
129	2012-11-14	16:00:00	16:45:00	1	8	11	2	0
130	2012-11-28	16:00:00	16:45:00	1	8	11	2	0
131	2012-12-12	16:00:00	16:45:00	1	8	11	2	0
132	2013-01-09	16:00:00	16:45:00	1	8	11	2	0
133	2013-01-23	16:00:00	16:45:00	1	8	11	2	0
134	2013-02-06	16:00:00	16:45:00	1	8	11	2	0
135	2013-03-06	16:00:00	16:45:00	1	8	11	2	0
136	2013-03-20	16:00:00	16:45:00	1	8	11	2	0
137	2013-04-03	16:00:00	16:45:00	1	8	11	2	0
138	2013-05-15	16:00:00	16:45:00	1	8	11	2	0
139	2013-05-29	16:00:00	16:45:00	1	8	11	2	0
140	2012-09-19	17:00:00	17:45:00	1	8	12	2	0
141	2012-10-03	17:00:00	17:45:00	1	8	12	2	0
142	2012-10-17	17:00:00	17:45:00	1	8	12	2	0
143	2012-11-14	17:00:00	17:45:00	1	8	12	2	0
144	2012-11-28	17:00:00	17:45:00	1	8	12	2	0
145	2012-12-12	17:00:00	17:45:00	1	8	12	2	0
146	2013-01-09	17:00:00	17:45:00	1	8	12	2	0
147	2013-01-23	17:00:00	17:45:00	1	8	12	2	0
148	2013-02-06	17:00:00	17:45:00	1	8	12	2	0
149	2013-03-06	17:00:00	17:45:00	1	8	12	2	0
150	2013-03-20	17:00:00	17:45:00	1	8	12	2	0
151	2013-04-03	17:00:00	17:45:00	1	8	12	2	0
152	2013-05-15	17:00:00	17:45:00	1	8	12	2	0
153	2013-05-29	17:00:00	17:45:00	1	8	12	2	0
154	2012-09-19	18:00:00	18:45:00	1	8	13	2	0
155	2012-10-03	18:00:00	18:45:00	1	8	13	2	0
156	2012-10-17	18:00:00	18:45:00	1	8	13	2	0
157	2012-11-14	18:00:00	18:45:00	1	8	13	2	0
158	2012-11-28	18:00:00	18:45:00	1	8	13	2	0
159	2012-12-12	18:00:00	18:45:00	1	8	13	2	0
160	2013-01-09	18:00:00	18:45:00	1	8	13	2	0
161	2013-01-23	18:00:00	18:45:00	1	8	13	2	0
162	2013-02-06	18:00:00	18:45:00	1	8	13	2	0
163	2013-03-06	18:00:00	18:45:00	1	8	13	2	0
164	2013-03-20	18:00:00	18:45:00	1	8	13	2	0
165	2013-04-03	18:00:00	18:45:00	1	8	13	2	0
166	2013-05-15	18:00:00	18:45:00	1	8	13	2	0
167	2013-05-29	18:00:00	18:45:00	1	8	13	2	0
168	2012-09-19	19:00:00	19:45:00	1	8	14	2	0
169	2012-10-03	19:00:00	19:45:00	1	8	14	2	0
170	2012-10-17	19:00:00	19:45:00	1	8	14	2	0
171	2012-11-14	19:00:00	19:45:00	1	8	14	2	0
172	2012-11-28	19:00:00	19:45:00	1	8	14	2	0
173	2012-12-12	19:00:00	19:45:00	1	8	14	2	0
174	2013-01-09	19:00:00	19:45:00	1	8	14	2	0
175	2013-01-23	19:00:00	19:45:00	1	8	14	2	0
176	2013-02-06	19:00:00	19:45:00	1	8	14	2	0
177	2013-03-06	19:00:00	19:45:00	1	8	14	2	0
178	2013-03-20	19:00:00	19:45:00	1	8	14	2	0
179	2013-04-03	19:00:00	19:45:00	1	8	14	2	0
180	2013-05-15	19:00:00	19:45:00	1	8	14	2	0
181	2013-05-29	19:00:00	19:45:00	1	8	14	2	0
\.


--
-- Data for Name: postit; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY postit (id, ptype, emet, dest, jour, echeance, texte) FROM stdin;
\.


--
-- Data for Name: prof; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY prof (idper, diplome1, diplome2, diplome3, actif) FROM stdin;
8				t
\.


--
-- Data for Name: reglement; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY reglement (id, mode) FROM stdin;
1	CHQ
2	ESP
3	PRL
4	VIR
5	NUL
6	FAC
\.


--
-- Data for Name: remplacement; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY remplacement (id_etab, id_cours, id_prof, id_remplacant, jours, favori) FROM stdin;
\.


--
-- Data for Name: rib; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY rib (idper, etablissement, guichet, compte, clerib, guichetid, iban) FROM stdin;
26	15459	37158	00010078903	23	27	\N
\.


--
-- Data for Name: salarie; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY salarie (idper, insee, datenais, lieunais, guso) FROM stdin;
\.


--
-- Data for Name: salle; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY salle (id, nom, fonction, surf, npers, etablissement, active, idtarif, idper, payeur, public) FROM stdin;
2	SALLE 2	Atelier	25	10	3	t	1	5	5	f
1	SALLE 1	Cours	20	2	3	t	1	4	4	f
0	 		0	0	3	f	1	1	1	f
\.


--
-- Data for Name: sallequip; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY sallequip (idsalle, libelle, qte, idx) FROM stdin;
1	Piano droit Yamaha	1	0
1	Micro Shure SM 57	1	1
1	Micro Shure SM 58	2	2
1	Ampli Guitare Peavey Bandit	1	3
\.


--
-- Data for Name: siteweb; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY siteweb (idx, idper, url, type, ptype) FROM stdin;
0	6	www.myspace.com/dupont	2	1
0	2	www.facebook.com/demo	3	3
1	6	www.pages.perso.dupont.fr	1	1
\.


--
-- Data for Name: statut; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY statut (id, code, libelle) FROM stdin;
0	-	Aucun
1	L	Loisir
2	P	Professionnel
\.


--
-- Data for Name: stylemus; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY stylemus (id, libelle) FROM stdin;
0	Autre
1	Rock
2	Rock-Inde
3	Blues-Rock
4	Rockabilly
5	Rock Progressif
6	Punk
7	Hard-Rock
8	Metal
9	Metal Prog
10	Pop
11	Pop-Rock
12	Reggae
13	Drum & Bass
14	Jazz
15	Fusion
16	Hip Hop
17	Rap
18	Salsa
19	R & B
20	World
21	Techno
22	Electro
23	Chanson
24	Expérimental
25	Acoustique
26	Vocal
27	Blues
28	Funk
30	Latin
31	Post-punk
32	MAA
\.


--
-- Data for Name: suivi; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY suivi (id, texte) FROM stdin;
1	gamme de ré
\.


--
-- Data for Name: tarifsalle; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY tarifsalle (id, libelle, type, hc, hp, plafond, forfaithc, forfaithp) FROM stdin;
1	Non défini	HORAIRE	0.0	0.0	0.0	0.0	0.0
\.


--
-- Data for Name: telephone; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY telephone (idper, idx, numero, typetel) FROM stdin;
6	0	01 02 03 04 05	1
6	1	06 01 02 03 04	8
\.


--
-- Data for Name: tiersproduit; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY tiersproduit (tiers, produit) FROM stdin;
11	2
\.


--
-- Data for Name: trancheage; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY trancheage (id, agemin, agemax, nom, code) FROM stdin;
0	-1	-1	Aucune	-
\.


--
-- Data for Name: tva; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY tva (id, pourcentage) FROM stdin;
1	0.0
2	2.1
3	5.5
4	7.0
5	19.6
\.


--
-- Data for Name: typetel; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY typetel (id, type) FROM stdin;
1	Domicile
2	Travail
3	Parent
4	Ami(e)
5	Tel ADH
6	N° Tel
7	Fax
8	Portable
9	Port.ADH
11	Port.pro
10	Port.parent
12	Bur - standard
14	Domicile second
\.


--
-- Data for Name: vacance; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY vacance (jour, ptype, vid, libelle) FROM stdin;
2013-06-08	0	1	ZA ETE 2013                     
2013-06-09	0	1	ZA ETE 2013                     
2013-06-10	0	1	ZA ETE 2013                     
2013-06-11	0	1	ZA ETE 2013                     
2013-06-12	0	1	ZA ETE 2013                     
2013-06-13	0	1	ZA ETE 2013                     
2013-06-14	0	1	ZA ETE 2013                     
2013-06-15	0	1	ZA ETE 2013                     
2013-06-16	0	1	ZA ETE 2013                     
2013-06-17	0	1	ZA ETE 2013                     
2013-06-18	0	1	ZA ETE 2013                     
2013-06-19	0	1	ZA ETE 2013                     
2013-06-20	0	1	ZA ETE 2013                     
2013-06-21	0	1	ZA ETE 2013                     
2013-06-22	0	1	ZA ETE 2013                     
2013-06-23	0	1	ZA ETE 2013                     
2013-06-24	0	1	ZA ETE 2013                     
2013-06-25	0	1	ZA ETE 2013                     
2013-06-26	0	1	ZA ETE 2013                     
2013-06-27	0	1	ZA ETE 2013                     
2013-06-28	0	1	ZA ETE 2013                     
2013-06-29	0	1	ZA ETE 2013                     
2013-06-30	0	1	ZA ETE 2013                     
2013-07-01	0	1	ZA ETE 2013                     
2013-07-02	0	1	ZA ETE 2013                     
2013-07-03	0	1	ZA ETE 2013                     
2013-07-04	0	1	ZA ETE 2013                     
2013-07-05	0	1	ZA ETE 2013                     
2013-07-06	0	1	ZA ETE 2013                     
2013-07-07	0	1	ZA ETE 2013                     
2013-07-08	0	1	ZA ETE 2013                     
2013-07-09	0	1	ZA ETE 2013                     
2013-07-10	0	1	ZA ETE 2013                     
2013-07-11	0	1	ZA ETE 2013                     
2013-07-12	0	1	ZA ETE 2013                     
2013-07-13	0	1	ZA ETE 2013                     
2013-07-14	0	1	ZA ETE 2013                     
2013-07-15	0	1	ZA ETE 2013                     
2013-07-16	0	1	ZA ETE 2013                     
2013-07-17	0	1	ZA ETE 2013                     
2013-07-18	0	1	ZA ETE 2013                     
2013-07-19	0	1	ZA ETE 2013                     
2013-07-20	0	1	ZA ETE 2013                     
2013-07-21	0	1	ZA ETE 2013                     
2013-07-22	0	1	ZA ETE 2013                     
2013-07-23	0	1	ZA ETE 2013                     
2013-07-24	0	1	ZA ETE 2013                     
2013-07-25	0	1	ZA ETE 2013                     
2013-07-26	0	1	ZA ETE 2013                     
2013-07-27	0	1	ZA ETE 2013                     
2013-07-28	0	1	ZA ETE 2013                     
2013-07-29	0	1	ZA ETE 2013                     
2013-07-30	0	1	ZA ETE 2013                     
2013-07-31	0	1	ZA ETE 2013                     
2013-08-01	0	1	ZA ETE 2013                     
2013-08-02	0	1	ZA ETE 2013                     
2013-08-03	0	1	ZA ETE 2013                     
2013-08-04	0	1	ZA ETE 2013                     
2013-08-05	0	1	ZA ETE 2013                     
2013-08-06	0	1	ZA ETE 2013                     
2013-08-07	0	1	ZA ETE 2013                     
2013-08-08	0	1	ZA ETE 2013                     
2013-08-09	0	1	ZA ETE 2013                     
2013-08-10	0	1	ZA ETE 2013                     
2013-08-11	0	1	ZA ETE 2013                     
2013-08-12	0	1	ZA ETE 2013                     
2013-08-13	0	1	ZA ETE 2013                     
2013-08-14	0	1	ZA ETE 2013                     
2013-08-15	0	1	ZA ETE 2013                     
2013-08-16	0	1	ZA ETE 2013                     
2013-08-17	0	1	ZA ETE 2013                     
2013-08-18	0	1	ZA ETE 2013                     
2013-08-19	0	1	ZA ETE 2013                     
2013-08-20	0	1	ZA ETE 2013                     
2013-08-21	0	1	ZA ETE 2013                     
2013-08-22	0	1	ZA ETE 2013                     
2013-08-23	0	1	ZA ETE 2013                     
2013-08-24	0	1	ZA ETE 2013                     
2013-08-25	0	1	ZA ETE 2013                     
2013-08-26	0	1	ZA ETE 2013                     
2013-08-27	0	1	ZA ETE 2013                     
2013-08-28	0	1	ZA ETE 2013                     
2013-08-29	0	1	ZA ETE 2013                     
2013-08-30	0	1	ZA ETE 2013                     
2013-08-31	0	1	ZA ETE 2013                     
2013-09-01	0	1	ZA ETE 2013                     
2013-09-02	0	1	ZA ETE 2013                     
2013-09-03	0	1	ZA ETE 2013                     
2013-09-04	0	1	ZA ETE 2013                     
2013-09-05	0	1	ZA ETE 2013                     
2013-09-06	0	1	ZA ETE 2013                     
2013-09-07	0	1	ZA ETE 2013                     
2013-09-08	0	1	ZA ETE 2013                     
2013-09-09	0	1	ZA ETE 2013                     
2013-09-10	0	1	ZA ETE 2013                     
2013-09-11	0	1	ZA ETE 2013                     
2013-09-12	0	1	ZA ETE 2013                     
2013-09-13	0	1	ZA ETE 2013                     
2013-09-14	0	1	ZA ETE 2013                     
2013-09-15	0	1	ZA ETE 2013                     
2013-07-06	0	2	ZB ETE 2013                     
2013-07-07	0	2	ZB ETE 2013                     
2013-07-08	0	2	ZB ETE 2013                     
2013-07-09	0	2	ZB ETE 2013                     
2013-07-10	0	2	ZB ETE 2013                     
2013-07-11	0	2	ZB ETE 2013                     
2013-07-12	0	2	ZB ETE 2013                     
2013-07-13	0	2	ZB ETE 2013                     
2013-07-14	0	2	ZB ETE 2013                     
2013-07-15	0	2	ZB ETE 2013                     
2013-07-16	0	2	ZB ETE 2013                     
2013-07-17	0	2	ZB ETE 2013                     
2013-07-18	0	2	ZB ETE 2013                     
2013-07-19	0	2	ZB ETE 2013                     
2013-07-20	0	2	ZB ETE 2013                     
2013-07-21	0	2	ZB ETE 2013                     
2013-07-22	0	2	ZB ETE 2013                     
2013-07-23	0	2	ZB ETE 2013                     
2013-07-24	0	2	ZB ETE 2013                     
2013-07-25	0	2	ZB ETE 2013                     
2013-07-26	0	2	ZB ETE 2013                     
2013-07-27	0	2	ZB ETE 2013                     
2013-07-28	0	2	ZB ETE 2013                     
2013-07-29	0	2	ZB ETE 2013                     
2013-07-30	0	2	ZB ETE 2013                     
2013-07-31	0	2	ZB ETE 2013                     
2013-08-01	0	2	ZB ETE 2013                     
2013-08-02	0	2	ZB ETE 2013                     
2013-08-03	0	2	ZB ETE 2013                     
2013-08-04	0	2	ZB ETE 2013                     
2013-08-05	0	2	ZB ETE 2013                     
2013-08-06	0	2	ZB ETE 2013                     
2013-08-07	0	2	ZB ETE 2013                     
2013-08-08	0	2	ZB ETE 2013                     
2013-08-09	0	2	ZB ETE 2013                     
2013-08-10	0	2	ZB ETE 2013                     
2013-08-11	0	2	ZB ETE 2013                     
2013-08-12	0	2	ZB ETE 2013                     
2013-08-13	0	2	ZB ETE 2013                     
2013-08-14	0	2	ZB ETE 2013                     
2013-08-15	0	2	ZB ETE 2013                     
2013-08-16	0	2	ZB ETE 2013                     
2013-08-17	0	2	ZB ETE 2013                     
2013-08-18	0	2	ZB ETE 2013                     
2013-08-19	0	2	ZB ETE 2013                     
2013-08-20	0	2	ZB ETE 2013                     
2013-08-21	0	2	ZB ETE 2013                     
2013-08-22	0	2	ZB ETE 2013                     
2013-08-23	0	2	ZB ETE 2013                     
2013-08-24	0	2	ZB ETE 2013                     
2013-08-25	0	2	ZB ETE 2013                     
2013-08-26	0	2	ZB ETE 2013                     
2013-08-27	0	2	ZB ETE 2013                     
2013-08-28	0	2	ZB ETE 2013                     
2013-08-29	0	2	ZB ETE 2013                     
2013-08-30	0	2	ZB ETE 2013                     
2013-08-31	0	2	ZB ETE 2013                     
2013-09-01	0	2	ZB ETE 2013                     
2013-09-02	0	2	ZB ETE 2013                     
2013-10-20	0	2	ZB TOUSSAINT 2013               
2013-10-21	0	2	ZB TOUSSAINT 2013               
2013-10-22	0	2	ZB TOUSSAINT 2013               
2013-10-23	0	2	ZB TOUSSAINT 2013               
2013-10-24	0	2	ZB TOUSSAINT 2013               
2013-10-25	0	2	ZB TOUSSAINT 2013               
2013-10-26	0	2	ZB TOUSSAINT 2013               
2013-10-27	0	2	ZB TOUSSAINT 2013               
2013-10-28	0	2	ZB TOUSSAINT 2013               
2013-10-29	0	2	ZB TOUSSAINT 2013               
2013-10-30	0	2	ZB TOUSSAINT 2013               
2013-10-31	0	2	ZB TOUSSAINT 2013               
2013-11-01	0	2	ZB TOUSSAINT 2013               
2013-11-02	0	2	ZB TOUSSAINT 2013               
2013-11-03	0	2	ZB TOUSSAINT 2013               
2013-12-22	0	2	ZB NOEL 2013                    
2013-12-23	0	2	ZB NOEL 2013                    
2013-12-24	0	2	ZB NOEL 2013                    
2013-12-25	0	2	ZB NOEL 2013                    
2013-12-26	0	2	ZB NOEL 2013                    
2013-12-27	0	2	ZB NOEL 2013                    
2013-12-28	0	2	ZB NOEL 2013                    
2013-12-29	0	2	ZB NOEL 2013                    
2013-12-30	0	2	ZB NOEL 2013                    
2013-12-31	0	2	ZB NOEL 2013                    
2014-01-01	0	2	ZB NOEL 2013                    
2014-01-02	0	2	ZB NOEL 2013                    
2014-01-03	0	2	ZB NOEL 2013                    
2014-01-04	0	2	ZB NOEL 2013                    
2014-01-05	0	2	ZB NOEL 2013                    
2014-02-23	0	2	ZB HIVER 2014                   
2014-02-24	0	2	ZB HIVER 2014                   
2014-02-25	0	2	ZB HIVER 2014                   
2014-02-26	0	2	ZB HIVER 2014                   
2014-02-27	0	2	ZB HIVER 2014                   
2014-02-28	0	2	ZB HIVER 2014                   
2014-03-01	0	2	ZB HIVER 2014                   
2014-03-02	0	2	ZB HIVER 2014                   
2014-03-03	0	2	ZB HIVER 2014                   
2014-03-04	0	2	ZB HIVER 2014                   
2014-03-05	0	2	ZB HIVER 2014                   
2014-03-06	0	2	ZB HIVER 2014                   
2014-03-07	0	2	ZB HIVER 2014                   
2014-03-08	0	2	ZB HIVER 2014                   
2014-03-09	0	2	ZB HIVER 2014                   
2014-04-20	0	2	ZB PRINTEMPS 2014               
2014-04-21	0	2	ZB PRINTEMPS 2014               
2014-04-22	0	2	ZB PRINTEMPS 2014               
2014-04-23	0	2	ZB PRINTEMPS 2014               
2014-04-24	0	2	ZB PRINTEMPS 2014               
2014-04-25	0	2	ZB PRINTEMPS 2014               
2014-04-26	0	2	ZB PRINTEMPS 2014               
2014-04-27	0	2	ZB PRINTEMPS 2014               
2014-04-28	0	2	ZB PRINTEMPS 2014               
2014-04-29	0	2	ZB PRINTEMPS 2014               
2014-04-30	0	2	ZB PRINTEMPS 2014               
2014-05-01	0	2	ZB PRINTEMPS 2014               
2014-05-02	0	2	ZB PRINTEMPS 2014               
2014-05-03	0	2	ZB PRINTEMPS 2014               
2014-05-04	0	2	ZB PRINTEMPS 2014               
2013-07-06	0	3	ZC ETE 2013                     
2013-07-07	0	3	ZC ETE 2013                     
2013-07-08	0	3	ZC ETE 2013                     
2013-07-09	0	3	ZC ETE 2013                     
2013-07-10	0	3	ZC ETE 2013                     
2013-07-11	0	3	ZC ETE 2013                     
2013-07-12	0	3	ZC ETE 2013                     
2013-07-13	0	3	ZC ETE 2013                     
2013-07-14	0	3	ZC ETE 2013                     
2013-07-15	0	3	ZC ETE 2013                     
2013-07-16	0	3	ZC ETE 2013                     
2013-07-17	0	3	ZC ETE 2013                     
2013-07-18	0	3	ZC ETE 2013                     
2013-07-19	0	3	ZC ETE 2013                     
2013-07-20	0	3	ZC ETE 2013                     
2013-07-21	0	3	ZC ETE 2013                     
2013-07-22	0	3	ZC ETE 2013                     
2013-07-23	0	3	ZC ETE 2013                     
2013-07-24	0	3	ZC ETE 2013                     
2013-07-25	0	3	ZC ETE 2013                     
2013-07-26	0	3	ZC ETE 2013                     
2013-07-27	0	3	ZC ETE 2013                     
2013-07-28	0	3	ZC ETE 2013                     
2013-07-29	0	3	ZC ETE 2013                     
2013-07-30	0	3	ZC ETE 2013                     
2013-07-31	0	3	ZC ETE 2013                     
2013-08-01	0	3	ZC ETE 2013                     
2013-08-02	0	3	ZC ETE 2013                     
2013-08-03	0	3	ZC ETE 2013                     
2013-08-04	0	3	ZC ETE 2013                     
2013-08-05	0	3	ZC ETE 2013                     
2013-08-06	0	3	ZC ETE 2013                     
2013-08-07	0	3	ZC ETE 2013                     
2013-08-08	0	3	ZC ETE 2013                     
2013-08-09	0	3	ZC ETE 2013                     
2013-08-10	0	3	ZC ETE 2013                     
2013-08-11	0	3	ZC ETE 2013                     
2013-08-12	0	3	ZC ETE 2013                     
2013-08-13	0	3	ZC ETE 2013                     
2013-08-14	0	3	ZC ETE 2013                     
2013-08-15	0	3	ZC ETE 2013                     
2013-08-16	0	3	ZC ETE 2013                     
2013-08-17	0	3	ZC ETE 2013                     
2013-08-18	0	3	ZC ETE 2013                     
2013-08-19	0	3	ZC ETE 2013                     
2013-08-20	0	3	ZC ETE 2013                     
2013-08-21	0	3	ZC ETE 2013                     
2013-08-22	0	3	ZC ETE 2013                     
2013-08-23	0	3	ZC ETE 2013                     
2013-08-24	0	3	ZC ETE 2013                     
2013-08-25	0	3	ZC ETE 2013                     
2013-08-26	0	3	ZC ETE 2013                     
2013-08-27	0	3	ZC ETE 2013                     
2013-08-28	0	3	ZC ETE 2013                     
2013-08-29	0	3	ZC ETE 2013                     
2013-08-30	0	3	ZC ETE 2013                     
2013-08-31	0	3	ZC ETE 2013                     
2013-09-01	0	3	ZC ETE 2013                     
2013-09-02	0	3	ZC ETE 2013                     
2013-10-20	0	3	ZC TOUSSAINT 2013               
2013-10-21	0	3	ZC TOUSSAINT 2013               
2013-10-20	0	1	ZA TOUSSAINT 2013               
2013-10-21	0	1	ZA TOUSSAINT 2013               
2013-10-22	0	1	ZA TOUSSAINT 2013               
2013-10-23	0	1	ZA TOUSSAINT 2013               
2013-10-24	0	1	ZA TOUSSAINT 2013               
2013-10-25	0	1	ZA TOUSSAINT 2013               
2013-10-26	0	1	ZA TOUSSAINT 2013               
2013-10-27	0	1	ZA TOUSSAINT 2013               
2013-10-28	0	1	ZA TOUSSAINT 2013               
2013-10-29	0	1	ZA TOUSSAINT 2013               
2013-10-30	0	1	ZA TOUSSAINT 2013               
2013-10-31	0	1	ZA TOUSSAINT 2013               
2013-11-01	0	1	ZA TOUSSAINT 2013               
2013-11-02	0	1	ZA TOUSSAINT 2013               
2013-11-03	0	1	ZA TOUSSAINT 2013               
2013-10-22	0	3	ZC TOUSSAINT 2013               
2013-10-23	0	3	ZC TOUSSAINT 2013               
2013-10-24	0	3	ZC TOUSSAINT 2013               
2013-10-25	0	3	ZC TOUSSAINT 2013               
2013-10-26	0	3	ZC TOUSSAINT 2013               
2013-10-27	0	3	ZC TOUSSAINT 2013               
2013-10-28	0	3	ZC TOUSSAINT 2013               
2013-10-29	0	3	ZC TOUSSAINT 2013               
2013-10-30	0	3	ZC TOUSSAINT 2013               
2013-10-31	0	3	ZC TOUSSAINT 2013               
2013-11-01	0	3	ZC TOUSSAINT 2013               
2013-11-02	0	3	ZC TOUSSAINT 2013               
2013-11-03	0	3	ZC TOUSSAINT 2013               
2013-12-22	0	1	ZA NOEL 2013                    
2013-12-23	0	1	ZA NOEL 2013                    
2013-12-24	0	1	ZA NOEL 2013                    
2013-12-25	0	1	ZA NOEL 2013                    
2013-12-26	0	1	ZA NOEL 2013                    
2013-12-27	0	1	ZA NOEL 2013                    
2013-12-28	0	1	ZA NOEL 2013                    
2013-12-29	0	1	ZA NOEL 2013                    
2013-12-30	0	1	ZA NOEL 2013                    
2013-12-31	0	1	ZA NOEL 2013                    
2014-01-01	0	1	ZA NOEL 2013                    
2014-01-02	0	1	ZA NOEL 2013                    
2014-01-03	0	1	ZA NOEL 2013                    
2014-01-04	0	1	ZA NOEL 2013                    
2014-01-05	0	1	ZA NOEL 2013                    
2014-03-02	0	1	ZA HIVER 2014                   
2014-03-03	0	1	ZA HIVER 2014                   
2014-03-04	0	1	ZA HIVER 2014                   
2014-03-05	0	1	ZA HIVER 2014                   
2014-03-06	0	1	ZA HIVER 2014                   
2014-03-07	0	1	ZA HIVER 2014                   
2014-03-08	0	1	ZA HIVER 2014                   
2014-03-09	0	1	ZA HIVER 2014                   
2014-03-10	0	1	ZA HIVER 2014                   
2014-03-11	0	1	ZA HIVER 2014                   
2014-03-12	0	1	ZA HIVER 2014                   
2014-03-13	0	1	ZA HIVER 2014                   
2014-03-14	0	1	ZA HIVER 2014                   
2014-03-15	0	1	ZA HIVER 2014                   
2014-03-16	0	1	ZA HIVER 2014                   
2014-04-27	0	1	ZA PRINTEMPS 2014               
2014-04-28	0	1	ZA PRINTEMPS 2014               
2014-04-29	0	1	ZA PRINTEMPS 2014               
2014-04-30	0	1	ZA PRINTEMPS 2014               
2014-05-01	0	1	ZA PRINTEMPS 2014               
2014-05-02	0	1	ZA PRINTEMPS 2014               
2014-05-03	0	1	ZA PRINTEMPS 2014               
2014-05-04	0	1	ZA PRINTEMPS 2014               
2014-05-05	0	1	ZA PRINTEMPS 2014               
2014-05-06	0	1	ZA PRINTEMPS 2014               
2014-05-07	0	1	ZA PRINTEMPS 2014               
2014-05-08	0	1	ZA PRINTEMPS 2014               
2014-05-09	0	1	ZA PRINTEMPS 2014               
2014-05-10	0	1	ZA PRINTEMPS 2014               
2014-05-11	0	1	ZA PRINTEMPS 2014               
2013-12-22	0	3	ZC NOEL 2013                    
2013-12-23	0	3	ZC NOEL 2013                    
2013-12-24	0	3	ZC NOEL 2013                    
2013-12-25	0	3	ZC NOEL 2013                    
2013-12-26	0	3	ZC NOEL 2013                    
2013-12-27	0	3	ZC NOEL 2013                    
2013-12-28	0	3	ZC NOEL 2013                    
2013-12-29	0	3	ZC NOEL 2013                    
2013-12-30	0	3	ZC NOEL 2013                    
2013-12-31	0	3	ZC NOEL 2013                    
2014-01-01	0	3	ZC NOEL 2013                    
2014-01-02	0	3	ZC NOEL 2013                    
2014-01-03	0	3	ZC NOEL 2013                    
2014-01-04	0	3	ZC NOEL 2013                    
2014-01-05	0	3	ZC NOEL 2013                    
2014-02-16	0	3	ZC HIVER 2014                   
2014-02-17	0	3	ZC HIVER 2014                   
2014-02-18	0	3	ZC HIVER 2014                   
2014-02-19	0	3	ZC HIVER 2014                   
2014-02-20	0	3	ZC HIVER 2014                   
2014-02-21	0	3	ZC HIVER 2014                   
2014-02-22	0	3	ZC HIVER 2014                   
2014-02-23	0	3	ZC HIVER 2014                   
2014-02-24	0	3	ZC HIVER 2014                   
2014-02-25	0	3	ZC HIVER 2014                   
2014-02-26	0	3	ZC HIVER 2014                   
2014-02-27	0	3	ZC HIVER 2014                   
2014-02-28	0	3	ZC HIVER 2014                   
2014-03-01	0	3	ZC HIVER 2014                   
2014-03-02	0	3	ZC HIVER 2014                   
2014-04-13	0	3	ZC PRINTEMPS 2014               
2014-04-14	0	3	ZC PRINTEMPS 2014               
2014-04-15	0	3	ZC PRINTEMPS 2014               
2014-04-16	0	3	ZC PRINTEMPS 2014               
2014-04-17	0	3	ZC PRINTEMPS 2014               
2014-04-18	0	3	ZC PRINTEMPS 2014               
2014-04-19	0	3	ZC PRINTEMPS 2014               
2014-04-20	0	3	ZC PRINTEMPS 2014               
2014-04-21	0	3	ZC PRINTEMPS 2014               
2014-04-22	0	3	ZC PRINTEMPS 2014               
2014-04-23	0	3	ZC PRINTEMPS 2014               
2014-04-24	0	3	ZC PRINTEMPS 2014               
2014-04-25	0	3	ZC PRINTEMPS 2014               
2014-04-26	0	3	ZC PRINTEMPS 2014               
2014-04-27	0	3	ZC PRINTEMPS 2014               
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY version (version) FROM stdin;
2.8.m   
\.


--
-- Data for Name: ville; Type: TABLE DATA; Schema: public; Owner: nobody
--

COPY ville (cdp, nom) FROM stdin;
13120	 GARDANNE           
27950	 ST JUST            
28410	 BECHERES/VESGRES   
32600	 L'ISLE JOURDAIN    
34080	 MONTPELLIER        
94290	VILLENEUVE LE ROI
72210	 ROEZE SUR SARTHE   
75001	 PARIS              
75002	 PARIS              
75003	 PARIS              
75005	 PARIS              
75006	 PARIS              
75008	 PARIS              
75009	 PARIS              
75010	 PARIS              
75011	 PARIS              
75012	 PARIS              
75013	 PARIS              
75014	 PARIS              
75015	 PARIS              
75016	 PARIS              
75017	 PARIS              
75018	 PARIS              
75019	 PARIS              
75020	 PARIS              
77160	 PROVINS            
77330	 OZOIR              
77380	 COMBS LA VILLE     
77400	 POMPONNE           
77420	 CHAMPS SUR MARNE   
77600	 BUSSY ST GEORGES   
78000	 VERSAILLES         
78100	 ST GERMAIN EN LAYE 
03000	MOULIN
78140	 VELIZY             
78150	 LE CHESNAY         
78160	 MARLY LE ROI       
78170	 LA CELLE ST CLOUD  
78200	 MANTES LA VILLE    
78210	 ST CYR L'ECOLE     
78220	 VIROFLAY           
78260	 ACHERES            
78300	 POISSY             
78310	 MAUREPAS           
78320	 LE MESNIL ST DENIS 
78330	 FONTENAY FLEURY    
78350	 JOUY EN JOSAS      
78370	 PLAISIR            
78390	 BOIS D'ARCY        
78400	 CHATOU             
78430	 LOUVECIENNES       
78470	 ST REMY L.CHEVREUSE
78530	 BUC                
78590	 NOISY LE ROI       
78600	 MAISON LAFFITTE    
78630	 ORGEVAL            
78640	 ST GERMAIN/GRANGE  
78770	 THOIRY             
78810	 FEUCHEROLLES       
78830	 BONNELLES          
78860	 ST NOM LA BRETECHE 
78870	 BAILLY             
78910	 TACOIGNIERES       
95600	EAUBONNE
89000	 AUXERRE            
89290	 VINCELOTTES        
91120	 PALAISEAU          
91130	 RIS ORANGIS        
91300	 MASSY              
91310	 MONTLHERY          
91370	 VERRIERE LE BUISSON
91400	 ORSAY              
91410	 DOURDAN            
91470	 LES MOLIERES       
91940	 LES ULIS           
92000	 NANTERRE           
92100	 BOULOGNE           
92110	 CLICHY LA GARENNE  
92120	 MONTROUGE          
92130	 ISSY LES MOULINEAUX
94480	 ABLON SUR SEINE    
21000	DIJON
92170	 VANVES             
78420	CARRIERES SUR SEINE
92200	 NEUILLY            
92210	 SAINT CLOUD        
92220	 BAGNEUX            
92230	 GENNEVILLIERS      
92350	 PLESSIS ROBINSON   
92250	 LA GARENNE COLOMBE 
92260	 FONTENAY AUX ROSES 
92270	 BOIS COLOMBES      
92290	 CHATENAY MALABRY   
92310	 SEVRES             
77178	ST PERTHUS
92330	 SCEAUX             
72000	LE MANS
92360	 MEUDON LA FORET    
92370	 CHAVILLE           
92380	 GARCHES            
95360	MONTMAGNY
92400	 COURBEVOIE         
92410	 VILLE D'AVRAY      
92420	 VAUCRESSON         
14100	LIZIEUX
92480	 GARCHES            
92500	 RUEIL MALMAISON    
92600	 ASNIERES           
92700	 COLOMBES           
92800	 PUTEAUX            
93100	 MONTREUIL          
93110	 ROSNY SOUS BOIS    
42390	VILLARS
70200	MALBOUHANS
93140	 BONDY              
93150	 LE BLANC MESNIL    
93160	 NOISY LE GRAND     
93170	 BAGNOLET           
93190	 LIVRY GARGAN       
93200	 ST DENIS           
93270	 SEVRAN             
93300	 AUBERVILLIERS      
93380	 PIERREFITTE / SEINE
94000	 CRETEIL            
94100	 ST MAUR DES FOSSES 
94120	 FONTENAY SOUS BOIS 
94130	 NOGENT SUR MARNE   
94200	 IVRY               
94220	 CHARENTON          
94230	 CACHAN             
94340	 JOINVILLE LE PONT  
87000	LIMOGES
94500	 CHAMPIGNY S/MARNE  
94600	 CHOISY LE ROI      
94700	 MAISON ALFORT      
95120	 ERMONT             
95150	 TAVERNY            
95170	 DEUIL LA BARRE     
95240	 CORNRILLES EN P.   
95330	 DOMONT             
95370	 MONTIGNY LES CORMEILLES
95620	 PARMAIN J. LE CONTE
78990	ELANCOURT
95180	MENUCOURT
95210	SAINT GRATIEN
89480	COULANGES SUR YONNE
92160	ANTONY
93370	MONTFERMEIL
22100	LEHON
51100	REIMS
78700	CONFLANS STE HONORINE
60280	CLAIROIX
56000	VANNES
37540	SAINT CYR SUR LOIRE
13200	ARLES
15001	AURILLAC CEDEX
91680	BRUYERES LE CHATEL
78660	PRUNAY EN YVELINES
95110	SANNOIS
78180	MONTIGNY LE BRETONNEUX
23220	BONNAT
28400	NOGENT LE ROTROU
06000	NICE
78190	TRAPPES
93240	STAINS
95800	CERGY
50009	SAINT LO
91360	VILLEMOISSON SUR ORGE
29200	BREST
28120	BAILLEAU LE PIN
75724	PARIS CEDEX 15
92521	NEUILLY
94270	LE KREMELIN BICETRE
94800	VILLEJUIF
78290	CROISSY SUR SEINE
95460	EZANVILLE
76620	LE HAVRE
91160	LONGJUMEAU
92683	LEVALLOIS PERRET CEDEX
91650	BREUX
75007	PARIS
28210	CROISILLES
44900	NANTES CHEQUES
92240	MALAKOFF
94110	ARCUEIL
34900	MONTPELLIER CHEQUES
33900	BORDEAUX CHEQUES
60500	CHANTILLY
13900	MARSEILLE CHEQUES
93310	LE PRÉ ST GERVAIS
77140	NEMOURS
94250	GENTILLY
93400	ST OUEN
78500	SARTROUVILLE
34000	MONTPELLIER
93700	DRANCY
77260	SEPT SORTS
78112	FOURQUEUX
94190	VILLENEUVE ST GEORGES
78340	LES CLAYES SOUS BOIS
44000	NANTES
94240	L'HAY LES ROSES
78610	LE PERRAY EN YVELINES
95380	LOUVRES
93130	NOISY LE SEC
37100	TOURS
91190	GIF SUR YVETTE
92340	BOURG LA REINE
02330	PARGNY LA DHUYS
76900	ROUEN CHÈQUES
76000	ROUEN
91230	WISSOUS
51120	REIMS
14400	BAYEUX
91640	VAUGRIGNEUSE
14500	VIRE
45900	LA SOURCE CHÈQUES
45007	ORLÉANS CEDEX
75004	PARIS
91540	MENNECY
14200	MERONVILLE
60390	AUNEUIL
94370	SUCY EN BRIE
91800	BRUNOY
61150	ECOUCHE
63000	CLERMONT-FERRAND
77130	LA GRANDE PAROISSE
91150	ETAMPES
78250	MEZY
93000	BOBIGNY
38110	LA CHAPELLE DE LA TOUR
22400	LAMBALLE
44340	BOUG
61300	LAIGLE
27300	BERNAY
78460	CHEVREUSE
91270	VIGNEUX SUR SEINE
80080	AMIENS
42000	SAINT ETIENNE
97200	FORT DE FRANCE
72220	ST GERVAIS
91620	LA VILLE DU BOIS
95610	ERAGNY S/ OISE
91390	MORSANG SUR ORGE
94430	CHENNEVIERES SUR MARNE
35000	RENNES
94520	MANDRES LES ROSES
77170	BRIE COMTE ROBERT
78450	VILLEPREUX
52300	DONJEUX
29100	DOUARNEZ
77860	QUINCY VOISINS
53220	POMAIN
84300	CAVAILLON
34920	LE CRES
80290	CROIXRAULT
69007	LYON
78780	MAURECOURT
30000	NIMES
17300	VERGEROUX
37600	ST SENOCH
94300	VINCENNES
01100	OYONNAX
24580	PLAZAC
78790	SEPTEUIL
78490	LES MESNULS
94450	LIMEIL BREVANNE
68260	KINGERSHEIM
37000	TOURS
13004	MARSEILLE
95100	ARGENTEUIL
76200	DIEPPE
81600	GAILLAC
91440	BURES SUR YVETTE
75116	PARIS
60000	BEAUVAIS
91710	VERT LE PETIT
77166	EVRY LES CHATEAUX
28130	VILLIERS LE MORHIER
31000	TOULOUSE
37260	ARTANNES
93173	BAGNOLET
94421	LA RIVIERE ST LOUIS
91100	CORBERIL ESSONNE
91000	EVRY
76570	GOUJILLIERES
77480	VILLUIS
42320	LA GRAND-CROIX
91700	VILLIERS S/ORGE
77250	MORET
91210	DRAVEIL
94260	FRESNES
77310	SAINT FARGEAU PONTHIERRY
77630	BARBIZON
77580	VILLIERS SUR MORIN
63160	BILLOM
77163	DAMMARTIN SUR TIGEAUX
77780	BOURRON MARLOTTE
78820	JUZIERS
77750	SAINT CYR SUR MORIN
94470	BOISSY ST LEGER
91290	ARPAJON
14270	SESNY AUX VIGNES
21160	PERREGNY LES DIJON
84320	ENTRAGUES
31300	TOULOUSE
38000	GRENOBLE
78311	MAUREPAS
83340	LE LUC
18200	SAINT AMAND MONTROND
78125	LA BOISSIERE ECOLE
14220	CROISILLES
51530	MAGENTA
34090	MONTPELLIER
78114	MAGNY LES HAMEAUX
28701	AUNEAU
84000	AVIGNON
22260	PONTRIEUX
18220	PARASSY
91220	BRETIGNY SUR ORGE
94420	LE PLESSIS TREVISE
93430	VILLETANEUSE
91070	BONDOUFLE
03410	DAUMERAT
77300	FOITAINEBLEAU
92320	CHATILLON
03600	COLOMBIERS
02100	SAINT QUENTIN
78120	SONCHAMP
92150	SURESNES
94140	ALFORTVILLE
95410	GROSLAY
93220	GAGNY
50460	QUERQUEVILLE
86300	CHAUVIGNY
32190	MEUDON
92190	MEUDON
92140	CLAMART
92430	MARNES LA COQUETTE
92390	VILLENEUVE-LA-GARENNE
45700	PANNES
94170	LE PERREUX
95300	PONTOISE
60620	ACY EN MELTIEN
1880 	LUXEMBOURG
93009	BOBIGNY CEDEX
66000	PERPIGNAN
29000	QUIMPER
78570	CHANTELOUP
64200	BIARRITZ
77720	MORMONT
69005	LYON
93260	MEUDON LA FORÊT
91240	ST MICHEL SUR ORGE
83100	TOULON
91170	VIRY CHATILLON
1218 	GRAND-SACONNEX-GENEVE
87100	LIMOGES
76240	BONSECOURS
50110	TOUR LA VILLE
74800	ST PIERRE EN FAUCIGNY
78440	PORCHEVILLE
78960	VOISIN LE BRETONNEUX
62170	MONTREUIL SUR MER
82700	MONTECH
44250	SAINT BREVIN LES PINS
40480	VIEUX BOUCAU LES BAINS
69100	VILLEURBANNE
85400	SAINT GEMME LA PLAINE
60200	COMPIEGNE
34500	BEZIERS
77550	MOISSY CRAMAYEL
61500	CHAILLOUÉ
46400	SAINT JEAN LAGINESTE
95580	MARGENCY
72600	LOUVIGNY
74420	HABERE LULLIN
74300	THIEZ
20145	SOLIEN ZARA
75900	PARIS CHEQUES
78980	SAINT HILLIERS LE BOIS
94160	SAINT MANDE
77240	VERT SAINT DENIS
80480	DURY
94210	LA VARENNE SAINT HILAIRE
78800	HOUILLES
54000	NANCY
91140	VILLEBON
91510	JANVILLE SUR JUINE
31005	TOULOUSE CEDEX 6
03120	LAPALISSE
69900	LYON CHEQUES
51200	EPERNAY
83700	SAINT RAPHAEL
56100	LORIENT
28000	CHARTRES
78520	LIMAY
42720	POUILLY SOUS CHARLIEU
14350	BENY-BOCAGE
21300	CHENOVE
1200 	BRUXELLES / BELGIQUE
29910	TRÉGUNC
60270	GOUVIEUX
91260	JUVISY
21330	CERILLY
91600	SAVIGNY SUR ORGE
60580	COY LA FORÊT
29950	CLOHARS-FOUESNANT
29170	FOUESNANT
21190	MEURSAULT
13100	AIX EN PROVENCE
77176	SAVIGNY LE TEMPLE
64000	PAU
74400	CHAMONIX
08000	CHARLEVILLE MEZIERE
35580	GOVEN
71100	SAINT RÉMY
72650	LA MILESSE
14430	DOZULE
03160	BOURBON-L'ARCHAMBAULT
95220	HERBLAY
91090	LISSES
62800	LIEVIN
49600	GESTE
76120	GRAND QUEVILLY
95123	CATANIA-ITALIE
53160	HAMBERS
57810	MAIZIERES LES VIC
71400	AUTUN
61260	LE THEIL SUR HUISNE
27000	EVREUX
11700	COMING
44600	SAINT NAZAIRE
77840	CROUY / OURCQ
77185	LOGNES
08260	AUVILLIERS-LES-FORGES
08013	CHARLEVILLE-MEZIÈRES CEDEX
58170	LUZY
61390	COURTOMER
27620	GASNY
27200	VERNON
94440	VILLECRESNES
36001	CHATEAUROUX
69870	SAINT NIZIER D'AZERGUES
94410	SAINT MAURICE
97500	SAINT-PIERRE ET MIQUELON
14530	LUC SUR MER
10320	JEUGNY
09000	FOIX
75383	PARIS CEDEX 01
91080	COURCOURONNES
30260	SAINT HILAIRE DE LA COTE
79450	SAINT AUBIN LE CLOUD
11500	QUILLAN
73420	DRUMETTAZ  CLARAFOND
95130	FRANCONVILLE GARENNE
91660	MERE VILLE
13009	MARSEILLE MAZARGUES
77124	PENCHARD
95700	ROISSY EN FRANCE
33000	BORDEAUX
77190	DAMMARY LES LYS
16200	JARNAC
10100	ROMILLY SUR SEINE
85470	BRÉTIGNOLLES SUR MER
59300	AULNOY
30760	AIGUEZE
85330	NOIRMOUTIER
07140	THINES
47270	ST JEAN DE THURAC
64320	BIZANOS
60800	SERY MAGNEVAL
26220	VESC / DIEULEFIT
37320	ESVRES
42600	MONTBRISON
42300	ROANNE
22420	LE VIEUX MARCHÉ
84220	LA CABRIERE D'AVIGNON
72300	SABLÉ SUR SARTHE
08200	SEDAN
81090	VALDURENQ
83140	SIX FOURS LES PLAGES
33600	PESSAC
44400	REZE
67960	ENTZHEIM
93360	NEUILLY PLAISANCE
78730	SAINT ARNOULT YVELINES
77120	COULOMMIERS
20000	AJACCIO
28131	MAINTENON
81570	CEMALENS
78711	MANTES LA VILLE
29600	MORLAIX
57150	CREUTZWALD
13500	MARTIGUES
77670	VERNOU SUR SEINE
35200	TOULOUSE
95200	SARCELLES
91430	IGNY
94350	VILLIER / MARNE
94400	VITRY SUR SEINE
93800	EPINAY SUR SEINE
37500	CHINON
43100	BRIOUDE
49100	ANGERS
78130	LES MUREAUX
33130	BEGLES
54900	NANCY
35700	RENNES
42400	ST CHAMOND
91530	SERMAISE
91200	ATHIS MONS
31250	REVEL
78670	VILLENNES SUR SEINE
30100	BREVANS
38500	VOIRON
77370	GASTINS
93460	GOURNAY SUR MARNE
59650	VILLENEUVE D'ASQ
77500	CHELLES
94510	LA QUEUE EN BRIE
02430	GAUCHY
71200	LE CREUSOT
92440	MALAKOFF
87900	LIMOGES CHEQUES
78110	LE VESINET
79000	NIORT
61170	LE MELE SUR SARTHE
29555	QUIMPER CEDEX 9 
61130	BELLEME
06250	VAL DE MOUGINS
27320	NONANCOURT
79400	ST MAIXENT L'ECOLE
60026	BEAUVAIS CEDEX
49000	ANGERS
77210	AVON
28260	GILLES
28350	SAINT-LUBIN-DES-JONCHERES
78280	GUYANCOURT
92300	LEVALLOIS PERRET
68100	MULHOUSE
77290	MITRY MORY
91580	AUVERS SAINT GEORGES
78230	LE PECQ
30140	GENERARGUES
91630	MAROLLES EN AX
91520	EGLY
07220	SAINT MONTAN
76280	CUVERVILLE EN COUX
95780	LA ROCHE GUYON
59000	LILLE
91380	CHILLY-MAZARIN
78760	PONCHARTRAIN
91740	CHALOU-MOULINEUX
06140	VENCE
73400	UGINE
47140	SAINT SYLVESTRE SUR LOT
67900	STRASBOURG
02000	LAON
03200	VICHY
78288	GUYANCOURT
59240	SAINT AMAND LES EAUX
10130	ERVY LE CHATEL
47000	AGEN
13008	MARSEILLE
45420	BONNY SUR LOIRE
22720	PLÉSIDY
76870	GAILLEFONTAINE
97429	PETITE ILE - LA REUNION
93340	LE RAINCY
57000	METZ
34070	MONTPELLIER
95140	GARGES LES GONESSE
78480	VERNEUIL / SEINE
62990	BEAURAINVILLE
58500	CLAMECY
29834	CARHAIX
56550	BELZ
62033	ARRAS CEDEX
46000	CAHORS
51000	REIMS
31400	TOULOUSE
91121	PALAISEAU
45000	ORLEANS
24200	SARLAT
92900	PARIS LA DEFENSE CEDEX
67009	STRASBOURG
59100	ROUBAIX
93210	LA PLAINE SAINT DENIS
34110	VIC LA GARDIOLE
93290	TREMBLAY EN FRANCE
45210	FERRIERES
13005	MARSEILLE
42007	SAINT ETIENNE
93500	PANTIN
29470	PLOUGASTEL-DOUALAS
93230	ROMAINVILLE
14000	CAEN
45560	ST DENIS EN VAL
56230	BERNE
91330	YERRES
77186	NOISIEL
91420	MORANGIS
73100	AIX LES BAINS
94320	THIAIS
08400	VOUZIERS
37230	LUYNES
91042	EVRY CEDEX
27530	EZY SUR EURE
60100	CREIL
95400	ARNOUVILLE-LES-GONESSE
92222	BAGNEUX
95430	AUVERS SUR OISE
91860	EPINAY SOUS SENART
19000	TULLE
19400	ARGENTAT
26110	NYONS
35240	RETIERS
12100	MILLAU
50340	LES PIEUX
77139	PUISEUX
62930	WIMEREUX
56140	MALESTROIT
29490	GUIPAVAS
27750	LA COUTURE BOUSSEY
32320	POUYLEBON
45100	ORLEANS
35900	RENNES CEDEX 9
41220	THOURY
80700	ROYE
22690	PLEUDIHEN SUR FRANCE
71670	LE BREUIL
22350	CAULNES
01440	VIRIAT
93440	DUGNY
95530	LA FRETTE SUR SEINE
93600	AULNAY SOUS BOIS
91610	BALLANCOURT
91350	GRIGNY
95870	BEZON
45130	MEUNG SUR LOIRE
86500	SAULGE
59370	MONS EN BAROEUL
50440	BEAUMONT HAGUE
92659	BOULOGNE-BILLANCOURT CEDEX
16120	BASSAC
78117	CHATEAUFORT
1401 	BRAZZAVILLE
94550	CHEVILLY LA RUE
25000	BESANCON
35550	PIPRIAC
75372	PARIS CEDEX 08
91550	PARAY VIEILLE POSTE
9240 	MALAKOFF
51088	REIMS CEDEX
10140	VENDEUVRE SUR BARSE
75852	PARIS CEDEX 17
31700	BLAGNAC 
38370	ST CLAIR DU RHÔNE
83119	BRUE-AURIAC
45200	MONTARGIS
76260	EU
69003	LYON
34360	ASSIGNAN
77150	LESIGNY
66140	CANET EN ROUSSILLON
38900	GRENOBLE CEDEX 9
50390	SAINT SAUVEUR LE VICOMTE
02700	TERGNIER
77700	MAGNY
78620	L'ETANG LA VILLE
78580	MAULE
33140	VILLENAVE D'ORMON
67000	STRASBOURG
35430	SAINT JOUAN DES GUERETS
78183	SAINT-QUENTIN-EN-YVELINES
06310	BEJAIA ALGERIE
88100	SAINT-DIE
77870	VULAINES S/ SEINE
15590	LASCELLE
78410	AUBERGENVILLE
77100	VILLENOY
54074	NANCY CEDEX
89150	VILLENEUVE LA DONDAGRE
19240	VARETZ
78540	VERNOUILLET
51510	COMPERTRIX
14052	CAEN
77690	MONTIGNY SUR LOING
12150	SEVERAC-LE-CHATEAU
41240	OUZOUER LE MARCHÉ
27540	IVRY LA BATAILLE
29391	QUIMPER 
81100	CASTRES
44800	SAINT HERBLAIN
93330	NEUILLY SUR MARNE
77127	LIEUSAINT
75616	PARIS CEDEX 12
35740	PACÉ
93320	PAVILLONS SOUS BOIS
19360	COSNAC
34700	LODÈVE
95310	SAINT OUEN L'AUMONE
40990	ST PAUL LES DAX
94138	FONTENAY SOUS BOIS CEDEX
58200	MENEREREAU - ST PERE
17450	FOURAS
92022	NANTERRE
06530	PEYMEINADE
77184	EMERAINVILLE
95670	MARLY LA VILLE
69001	LYON
16220	VOUTHON
59890	QUESNOY SUR DEULE
37390	CERELLES
41500	LA CHAPELLE SAINT MARTIN
37700	LA VILLE AUX DAMES
37300	JOUE LES TOURS
85530	LA BRUFFIERE
72310	VIBRAYE
37420	BEAUMONT EN VERON
45800	SAINT JEAN SUR BRAYE
72340	BEAUMONT SUR DEME
37270	MONTLOUIS SUR LOIRE
49730	MONTSOREAU
85240	NIEUL SUR L'AUTISE
72110	COURCEMONT
37370	CHEMILLÉ SUR DEME
36130	MONTIERCHAUME
37520	LA RICHE
41170	SAINT AGIL
37200	TOURS
35120	BAGUER PICAN
37550	ST AVERTIN
37110	CHATEAU RENAULT
37210	ROCHECORBON
\.


--
-- Name: action_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: analytique_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY analytique
    ADD CONSTRAINT analytique_pkey PRIMARY KEY (code);


--
-- Name: article_devis_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY article_devis
    ADD CONSTRAINT article_devis_pkey PRIMARY KEY (id_devis, id_article);


--
-- Name: article_facture_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY article_facture
    ADD CONSTRAINT article_facture_pkey PRIMARY KEY (id_facture, id_article);


--
-- Name: article_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY article
    ADD CONSTRAINT article_pkey PRIMARY KEY (id);


--
-- Name: banque_pk; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY banque
    ADD CONSTRAINT banque_pk PRIMARY KEY (code);


--
-- Name: carteaborepet_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY carteaborepet
    ADD CONSTRAINT carteaborepet_pkey PRIMARY KEY (id);


--
-- Name: commande_cours_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY commande_cours
    ADD CONSTRAINT commande_cours_pkey PRIMARY KEY (id);


--
-- Name: compte_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY compte
    ADD CONSTRAINT compte_pkey PRIMARY KEY (id);


--
-- Name: comptepref_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY comptepref
    ADD CONSTRAINT comptepref_pkey PRIMARY KEY (id);


--
-- Name: config_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY config
    ADD CONSTRAINT config_pkey PRIMARY KEY (clef);


--
-- Name: cours_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY cours
    ADD CONSTRAINT cours_pkey PRIMARY KEY (id);


--
-- Name: devis_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY devis
    ADD CONSTRAINT devis_pkey PRIMARY KEY (numero);


--
-- Name: echeancier2_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY echeancier2
    ADD CONSTRAINT echeancier2_pkey PRIMARY KEY (oid);


--
-- Name: facture_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY facture
    ADD CONSTRAINT facture_pkey PRIMARY KEY (numero);


--
-- Name: genre_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY stylemus
    ADD CONSTRAINT genre_pkey PRIMARY KEY (id);


--
-- Name: groupe_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY groupe
    ADD CONSTRAINT groupe_pkey PRIMARY KEY (id);


--
-- Name: instrument_pk; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY instrument
    ADD CONSTRAINT instrument_pk PRIMARY KEY (id);


--
-- Name: journalcompta_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY journalcompta
    ADD CONSTRAINT journalcompta_pkey PRIMARY KEY (id);


--
-- Name: module_pk; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY module
    ADD CONSTRAINT module_pk PRIMARY KEY (id);


--
-- Name: module_type_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY module_type
    ADD CONSTRAINT module_type_pkey PRIMARY KEY (id);


--
-- Name: niveau_code_key; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY niveau
    ADD CONSTRAINT niveau_code_key UNIQUE (code);


--
-- Name: niveau_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY niveau
    ADD CONSTRAINT niveau_pkey PRIMARY KEY (id);


--
-- Name: notes_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY note
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: person_instrument_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY person_instrument
    ADD CONSTRAINT person_instrument_pkey PRIMARY KEY (id);


--
-- Name: personne_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY personne
    ADD CONSTRAINT personne_pkey PRIMARY KEY (id);


--
-- Name: pk_guichet; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY guichet
    ADD CONSTRAINT pk_guichet PRIMARY KEY (id);


--
-- Name: pk_module_cours; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY module_cours
    ADD CONSTRAINT pk_module_cours PRIMARY KEY (id, idmodule);


--
-- Name: plage_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY plage
    ADD CONSTRAINT plage_pkey PRIMARY KEY (id);


--
-- Name: planning_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY planning
    ADD CONSTRAINT planning_pkey PRIMARY KEY (id);


--
-- Name: remplacement_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY remplacement
    ADD CONSTRAINT remplacement_pkey PRIMARY KEY (id_etab, id_cours, id_prof, id_remplacant);


--
-- Name: salarie_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY salarie
    ADD CONSTRAINT salarie_pkey PRIMARY KEY (idper);


--
-- Name: salle_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY salle
    ADD CONSTRAINT salle_pkey PRIMARY KEY (id);


--
-- Name: siteweb_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY siteweb
    ADD CONSTRAINT siteweb_pkey PRIMARY KEY (idx, idper, ptype);


--
-- Name: statut_code_key; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY statut
    ADD CONSTRAINT statut_code_key UNIQUE (code);


--
-- Name: statut_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY statut
    ADD CONSTRAINT statut_pkey PRIMARY KEY (id);


--
-- Name: suivi_pk; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY suivi
    ADD CONSTRAINT suivi_pk PRIMARY KEY (id);


--
-- Name: tarifsalle_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY tarifsalle
    ADD CONSTRAINT tarifsalle_pkey PRIMARY KEY (id);


--
-- Name: tiersproduit_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY tiersproduit
    ADD CONSTRAINT tiersproduit_pkey PRIMARY KEY (tiers);


--
-- Name: trancheage_code_key; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY trancheage
    ADD CONSTRAINT trancheage_code_key UNIQUE (code);


--
-- Name: trancheage_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY trancheage
    ADD CONSTRAINT trancheage_pkey PRIMARY KEY (id);


--
-- Name: tva_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY tva
    ADD CONSTRAINT tva_pkey PRIMARY KEY (id);


--
-- Name: typetel_pkey; Type: CONSTRAINT; Schema: public; Owner: nobody; Tablespace: 
--

ALTER TABLE ONLY typetel
    ADD CONSTRAINT typetel_pkey PRIMARY KEY (id);


--
-- Name: adx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX adx1 ON adresse USING btree (idper);


--
-- Name: bex1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX bex1 ON banque USING btree (code);


--
-- Name: bgx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX bgx1 ON guichet USING btree (code);


--
-- Name: bqx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX bqx1 ON rib USING btree (idper);


--
-- Name: cdx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX cdx1 ON commande USING btree (id);


--
-- Name: cdx2; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX cdx2 ON commande USING btree (adh);


--
-- Name: cx2; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX cx2 ON cours USING btree (titre);


--
-- Name: dx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX dx1 ON droits USING btree (idper);


--
-- Name: echeance_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX echeance_idx ON echeancier2 USING btree (echeance);


--
-- Name: elx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX elx1 ON eleve USING btree (idper);


--
-- Name: group_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX group_idx ON groupe_det USING btree (id);


--
-- Name: idx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX idx1 ON personne USING btree (id);


--
-- Name: idx2; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX idx2 ON personne USING btree (nom);


--
-- Name: nts1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX nts1 ON suivi USING btree (id);


--
-- Name: ntx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX ntx1 ON note USING btree (id);


--
-- Name: plage_idplanning_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX plage_idplanning_idx ON plage USING btree (idplanning);


--
-- Name: planning_action_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX planning_action_idx ON planning USING btree (action);


--
-- Name: planning_jour_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX planning_jour_idx ON planning USING btree (jour);


--
-- Name: prx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX prx1 ON prof USING btree (idper);


--
-- Name: psx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX psx1 ON postit USING btree (id);


--
-- Name: slx2; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX slx2 ON salle USING btree (nom);


--
-- Name: tlx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX tlx1 ON telephone USING btree (idper);


--
-- Name: vacance_id_idx; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX vacance_id_idx ON vacance USING btree (vid);


--
-- Name: vax1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE INDEX vax1 ON vacance USING btree (jour);


--
-- Name: vdx1; Type: INDEX; Schema: public; Owner: nobody; Tablespace: 
--

CREATE UNIQUE INDEX vdx1 ON ville USING btree (cdp);


--
-- Name: article_devis_id_devis_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY article_devis
    ADD CONSTRAINT article_devis_id_devis_fkey FOREIGN KEY (id_devis) REFERENCES devis(numero) ON DELETE CASCADE;


--
-- Name: article_facture_id_facture_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY article_facture
    ADD CONSTRAINT article_facture_id_facture_fkey FOREIGN KEY (id_facture) REFERENCES facture(numero) ON DELETE CASCADE;


--
-- Name: carteabopersonne_idper; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY carteabopersonne
    ADD CONSTRAINT carteabopersonne_idper FOREIGN KEY (idper) REFERENCES personne(id) ON DELETE RESTRICT;


--
-- Name: groupe_genre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY groupe
    ADD CONSTRAINT groupe_genre_fkey FOREIGN KEY (style) REFERENCES stylemus(id) ON DELETE SET DEFAULT;


--
-- Name: groupe_manager_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY groupe
    ADD CONSTRAINT groupe_manager_fkey FOREIGN KEY (manager) REFERENCES personne(id) ON DELETE SET DEFAULT;


--
-- Name: groupe_referent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY groupe
    ADD CONSTRAINT groupe_referent_fkey FOREIGN KEY (referent) REFERENCES personne(id) ON DELETE SET DEFAULT;


--
-- Name: groupe_tourneur_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY groupe
    ADD CONSTRAINT groupe_tourneur_fkey FOREIGN KEY (tourneur) REFERENCES personne(id) ON DELETE SET DEFAULT;


--
-- Name: person_instrument_instrument_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY person_instrument
    ADD CONSTRAINT person_instrument_instrument_fkey FOREIGN KEY (instrument) REFERENCES instrument(id) ON DELETE SET DEFAULT;


--
-- Name: salarie_idper_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY salarie
    ADD CONSTRAINT salarie_idper_fkey FOREIGN KEY (idper) REFERENCES personne(id) ON DELETE CASCADE;


--
-- Name: salle_idper_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY salle
    ADD CONSTRAINT salle_idper_fkey FOREIGN KEY (idper) REFERENCES personne(id);


--
-- Name: tarif_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY salle
    ADD CONSTRAINT tarif_fkey FOREIGN KEY (idtarif) REFERENCES tarifsalle(id);


--
-- Name: typetel_fk; Type: FK CONSTRAINT; Schema: public; Owner: nobody
--

ALTER TABLE ONLY telephone
    ADD CONSTRAINT typetel_fk FOREIGN KEY (typetel) REFERENCES typetel(id) ON DELETE SET DEFAULT;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: adresse; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE adresse FROM PUBLIC;
REVOKE ALL ON TABLE adresse FROM nobody;
GRANT ALL ON TABLE adresse TO nobody;


--
-- Name: atelier_ins; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE atelier_ins FROM PUBLIC;
REVOKE ALL ON TABLE atelier_ins FROM nobody;
GRANT ALL ON TABLE atelier_ins TO nobody;


--
-- Name: banque; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE banque FROM PUBLIC;
REVOKE ALL ON TABLE banque FROM nobody;
GRANT ALL ON TABLE banque TO nobody;


--
-- Name: categorie_prof; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE categorie_prof FROM PUBLIC;
REVOKE ALL ON TABLE categorie_prof FROM nobody;
GRANT ALL ON TABLE categorie_prof TO nobody;


--
-- Name: categorie_siteweb; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE categorie_siteweb FROM PUBLIC;
REVOKE ALL ON TABLE categorie_siteweb FROM nobody;
GRANT ALL ON TABLE categorie_siteweb TO nobody;


--
-- Name: categorie_vacance; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE categorie_vacance FROM PUBLIC;
REVOKE ALL ON TABLE categorie_vacance FROM nobody;
GRANT ALL ON TABLE categorie_vacance TO nobody;
GRANT ALL ON TABLE categorie_vacance TO postgres;


--
-- Name: categorie_vacance_id_seq; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE categorie_vacance_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE categorie_vacance_id_seq FROM nobody;
GRANT ALL ON SEQUENCE categorie_vacance_id_seq TO nobody;
GRANT ALL ON SEQUENCE categorie_vacance_id_seq TO postgres;


--
-- Name: cdpret; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE cdpret FROM PUBLIC;
REVOKE ALL ON TABLE cdpret FROM nobody;
GRANT ALL ON TABLE cdpret TO nobody;


--
-- Name: cdrom; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE cdrom FROM PUBLIC;
REVOKE ALL ON TABLE cdrom FROM nobody;
GRANT ALL ON TABLE cdrom TO nobody;


--
-- Name: cdtitre; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE cdtitre FROM PUBLIC;
REVOKE ALL ON TABLE cdtitre FROM nobody;
GRANT ALL ON TABLE cdtitre TO nobody;


--
-- Name: commande; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE commande FROM PUBLIC;
REVOKE ALL ON TABLE commande FROM nobody;
GRANT ALL ON TABLE commande TO nobody;


--
-- Name: idcours; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idcours FROM PUBLIC;
REVOKE ALL ON SEQUENCE idcours FROM nobody;
GRANT ALL ON SEQUENCE idcours TO nobody;


--
-- Name: cours; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE cours FROM PUBLIC;
REVOKE ALL ON TABLE cours FROM nobody;
GRANT ALL ON TABLE cours TO nobody;


--
-- Name: droits; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE droits FROM PUBLIC;
REVOKE ALL ON TABLE droits FROM nobody;
GRANT ALL ON TABLE droits TO nobody;


--
-- Name: echeancier2; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE echeancier2 FROM PUBLIC;
REVOKE ALL ON TABLE echeancier2 FROM nobody;
GRANT ALL ON TABLE echeancier2 TO nobody;
GRANT ALL ON TABLE echeancier2 TO postgres;


--
-- Name: echeancier2_oid_seq; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE echeancier2_oid_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE echeancier2_oid_seq FROM nobody;
GRANT ALL ON SEQUENCE echeancier2_oid_seq TO nobody;
GRANT ALL ON SEQUENCE echeancier2_oid_seq TO postgres;


--
-- Name: eleve; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE eleve FROM PUBLIC;
REVOKE ALL ON TABLE eleve FROM nobody;
GRANT ALL ON TABLE eleve TO nobody;


--
-- Name: email; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE email FROM PUBLIC;
REVOKE ALL ON TABLE email FROM nobody;
GRANT ALL ON TABLE email TO nobody;


--
-- Name: facture; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE facture FROM PUBLIC;
REVOKE ALL ON TABLE facture FROM nobody;
GRANT ALL ON TABLE facture TO nobody;
GRANT ALL ON TABLE facture TO postgres;


--
-- Name: groupe; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE groupe FROM PUBLIC;
REVOKE ALL ON TABLE groupe FROM nobody;
GRANT ALL ON TABLE groupe TO nobody;


--
-- Name: groupe_det; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE groupe_det FROM PUBLIC;
REVOKE ALL ON TABLE groupe_det FROM nobody;
GRANT ALL ON TABLE groupe_det TO nobody;


--
-- Name: groupe_id_seq; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE groupe_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE groupe_id_seq FROM nobody;
GRANT ALL ON SEQUENCE groupe_id_seq TO nobody;


--
-- Name: guichet; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE guichet FROM PUBLIC;
REVOKE ALL ON TABLE guichet FROM nobody;
GRANT ALL ON TABLE guichet TO nobody;


--
-- Name: idafaire; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idafaire FROM PUBLIC;
REVOKE ALL ON SEQUENCE idafaire FROM nobody;
GRANT ALL ON SEQUENCE idafaire TO nobody;


--
-- Name: idcategorieprof; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idcategorieprof FROM PUBLIC;
REVOKE ALL ON SEQUENCE idcategorieprof FROM nobody;
GRANT ALL ON SEQUENCE idcategorieprof TO nobody;


--
-- Name: idcdrom; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idcdrom FROM PUBLIC;
REVOKE ALL ON SEQUENCE idcdrom FROM nobody;
GRANT ALL ON SEQUENCE idcdrom TO nobody;


--
-- Name: idcommande; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idcommande FROM PUBLIC;
REVOKE ALL ON SEQUENCE idcommande FROM nobody;
GRANT ALL ON SEQUENCE idcommande TO nobody;


--
-- Name: idetab; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idetab FROM PUBLIC;
REVOKE ALL ON SEQUENCE idetab FROM nobody;
GRANT ALL ON SEQUENCE idetab TO nobody;


--
-- Name: idforfait; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idforfait FROM PUBLIC;
REVOKE ALL ON SEQUENCE idforfait FROM nobody;
GRANT ALL ON SEQUENCE idforfait TO nobody;


--
-- Name: idinstrument; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idinstrument FROM PUBLIC;
REVOKE ALL ON SEQUENCE idinstrument FROM nobody;
GRANT ALL ON SEQUENCE idinstrument TO nobody;


--
-- Name: idmajoration; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idmajoration FROM PUBLIC;
REVOKE ALL ON SEQUENCE idmajoration FROM nobody;
GRANT ALL ON SEQUENCE idmajoration TO nobody;


--
-- Name: idmodule; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idmodule FROM PUBLIC;
REVOKE ALL ON SEQUENCE idmodule FROM nobody;
GRANT ALL ON SEQUENCE idmodule TO nobody;


--
-- Name: idmoduletype; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idmoduletype FROM PUBLIC;
REVOKE ALL ON SEQUENCE idmoduletype FROM nobody;
GRANT ALL ON SEQUENCE idmoduletype TO nobody;


--
-- Name: idnote; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idnote FROM PUBLIC;
REVOKE ALL ON SEQUENCE idnote FROM nobody;
GRANT ALL ON SEQUENCE idnote TO nobody;


--
-- Name: idper; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idper FROM PUBLIC;
REVOKE ALL ON SEQUENCE idper FROM nobody;
GRANT ALL ON SEQUENCE idper TO nobody;


--
-- Name: idpostit; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idpostit FROM PUBLIC;
REVOKE ALL ON SEQUENCE idpostit FROM nobody;
GRANT ALL ON SEQUENCE idpostit TO nobody;


--
-- Name: idsalle; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idsalle FROM PUBLIC;
REVOKE ALL ON SEQUENCE idsalle FROM nobody;
GRANT ALL ON SEQUENCE idsalle TO nobody;


--
-- Name: idsuivi; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE idsuivi FROM PUBLIC;
REVOKE ALL ON SEQUENCE idsuivi FROM nobody;
GRANT ALL ON SEQUENCE idsuivi TO nobody;


--
-- Name: instrument; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE instrument FROM PUBLIC;
REVOKE ALL ON TABLE instrument FROM nobody;
GRANT ALL ON TABLE instrument TO nobody;


--
-- Name: login; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE login FROM PUBLIC;
REVOKE ALL ON TABLE login FROM nobody;
GRANT ALL ON TABLE login TO nobody;


--
-- Name: maintenance; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE maintenance FROM PUBLIC;
REVOKE ALL ON TABLE maintenance FROM nobody;
GRANT ALL ON TABLE maintenance TO nobody;


--
-- Name: majoration; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE majoration FROM PUBLIC;
REVOKE ALL ON TABLE majoration FROM nobody;
GRANT ALL ON TABLE majoration TO nobody;


--
-- Name: menu; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE menu FROM PUBLIC;
REVOKE ALL ON TABLE menu FROM nobody;
GRANT ALL ON TABLE menu TO nobody;


--
-- Name: menu2; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE menu2 FROM PUBLIC;
REVOKE ALL ON TABLE menu2 FROM nobody;
GRANT ALL ON TABLE menu2 TO nobody;


--
-- Name: menuaccess; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE menuaccess FROM PUBLIC;
REVOKE ALL ON TABLE menuaccess FROM nobody;
GRANT ALL ON TABLE menuaccess TO nobody;


--
-- Name: menuprofil; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE menuprofil FROM PUBLIC;
REVOKE ALL ON TABLE menuprofil FROM nobody;
GRANT ALL ON TABLE menuprofil TO nobody;


--
-- Name: module; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE module FROM PUBLIC;
REVOKE ALL ON TABLE module FROM nobody;
GRANT ALL ON TABLE module TO nobody;


--
-- Name: module_compo; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE module_compo FROM PUBLIC;
REVOKE ALL ON TABLE module_compo FROM nobody;
GRANT ALL ON TABLE module_compo TO nobody;


--
-- Name: module_type; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE module_type FROM PUBLIC;
REVOKE ALL ON TABLE module_type FROM nobody;
GRANT ALL ON TABLE module_type TO nobody;


--
-- Name: note; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE note FROM PUBLIC;
REVOKE ALL ON TABLE note FROM nobody;
GRANT ALL ON TABLE note TO nobody;


--
-- Name: personne; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE personne FROM PUBLIC;
REVOKE ALL ON TABLE personne FROM nobody;
GRANT ALL ON TABLE personne TO nobody;


--
-- Name: salle; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE salle FROM PUBLIC;
REVOKE ALL ON TABLE salle FROM nobody;
GRANT ALL ON TABLE salle TO nobody;


--
-- Name: planningvue; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE planningvue FROM PUBLIC;
REVOKE ALL ON TABLE planningvue FROM postgres;
GRANT ALL ON TABLE planningvue TO postgres;
GRANT ALL ON TABLE planningvue TO nobody;


--
-- Name: postit; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE postit FROM PUBLIC;
REVOKE ALL ON TABLE postit FROM nobody;
GRANT ALL ON TABLE postit TO nobody;


--
-- Name: prof; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE prof FROM PUBLIC;
REVOKE ALL ON TABLE prof FROM nobody;
GRANT ALL ON TABLE prof TO nobody;


--
-- Name: remplacement; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE remplacement FROM PUBLIC;
REVOKE ALL ON TABLE remplacement FROM nobody;
GRANT ALL ON TABLE remplacement TO nobody;
GRANT ALL ON TABLE remplacement TO postgres;


--
-- Name: rib; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE rib FROM PUBLIC;
REVOKE ALL ON TABLE rib FROM nobody;
GRANT ALL ON TABLE rib TO nobody;


--
-- Name: sallequip; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE sallequip FROM PUBLIC;
REVOKE ALL ON TABLE sallequip FROM nobody;
GRANT ALL ON TABLE sallequip TO nobody;


--
-- Name: siteweb; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE siteweb FROM PUBLIC;
REVOKE ALL ON TABLE siteweb FROM nobody;
GRANT ALL ON TABLE siteweb TO nobody;


--
-- Name: stylemus_id_seq; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON SEQUENCE stylemus_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE stylemus_id_seq FROM nobody;
GRANT ALL ON SEQUENCE stylemus_id_seq TO nobody;
GRANT ALL ON SEQUENCE stylemus_id_seq TO postgres;


--
-- Name: stylemus; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE stylemus FROM PUBLIC;
REVOKE ALL ON TABLE stylemus FROM nobody;
GRANT ALL ON TABLE stylemus TO nobody;


--
-- Name: suivi; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE suivi FROM PUBLIC;
REVOKE ALL ON TABLE suivi FROM nobody;
GRANT ALL ON TABLE suivi TO nobody;


--
-- Name: telephone; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE telephone FROM PUBLIC;
REVOKE ALL ON TABLE telephone FROM nobody;
GRANT ALL ON TABLE telephone TO nobody;


--
-- Name: vacance; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE vacance FROM PUBLIC;
REVOKE ALL ON TABLE vacance FROM nobody;
GRANT ALL ON TABLE vacance TO nobody;


--
-- Name: ville; Type: ACL; Schema: public; Owner: nobody
--

REVOKE ALL ON TABLE ville FROM PUBLIC;
REVOKE ALL ON TABLE ville FROM nobody;
GRANT ALL ON TABLE ville TO nobody;


--
-- PostgreSQL database dump complete
--

